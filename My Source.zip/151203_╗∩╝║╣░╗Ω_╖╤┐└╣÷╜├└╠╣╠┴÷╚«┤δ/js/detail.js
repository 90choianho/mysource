$(document).ready(function(){
	setDetail();
	//tabUlListFunc();
	setClickEvt();
});

function setDetail(){
	if($('#prdImgWrap').length>0){
		var prdImg=$('#prdImgWrap'), viewItem=5, totalI, thumb=$('#prdImgWrap .thumbnail li');
		//thumnail slider
		var goodsImg=$('#prdImgWrap .thumbnail ul').lightSlider({
			item:viewItem,
			vertical:true,
			verticalHeight:420,
			slideMargin:5,
			pager:false,
			onSliderLoad:function(el){
				tatalI=el.getTotalSlideCount()-viewItem;
				prdImg.find('.lSAction a').eq(0).addClass('end');
			},
			onBeforeSlide:function(el, i){
				if(i==0 || i==tatalI) prdImg.find('.lSAction a').eq(i==0?0:1).addClass('end');
				else if(i==1 || i==tatalI-1) prdImg.find('.lSAction a').removeClass('end');
			}
		});
		thumb.bind('click', thumbClick);
		prdImg.find('.prdImg li').bind({
			'mousemove': zoomImg,
			'mouseleave': function(){$(this).children('.zoomImg').hide()}
		});
	}

}

function thumbClick(){
	var idx=$(this).index(), $img=$(this).parents('#prdImgWrap').find('.prdImg li');
	var viewNum=$(this).siblings().is('.on')?$(this).siblings('.on').index():0, dur=500;
	$img.eq(viewNum).stop().animate({'opacity':0}, dur, function(){
		$(this).hide();
	});
	$img.eq(idx).show().stop().animate({'opacity':1}, dur);
	$(this).addClass('on').siblings().removeClass('on');
	return false;
}

function zoomImg(e){
	var gap=50, zoom=$(this).children('.zoomImg');
	zoom.show();
	var x=e.clientX-$(this).offset().left, y=e.clientY+$(window).scrollTop()-$(this).offset().top, img=zoom.children('img');
	var w=$(this).width(), h=$(this).height(), 
		wSizeGap=img.width()-zoom.width(), hSizeGap=img.height()-zoom.height();
	var wRate=x/w, hRate=y/h, wGapRate=((x-gap)/((w-gap*2)/2)-1)*gap,
		hGapRate=((y-gap)/((h-gap*2)/2)-1)*gap;
	var wPst, hPst;

	if(x>w) $(this).trigger('mouseleave');

	if(x>gap && x<w-gap) wPst=x*(img.width()/w)-(wRate*zoom.width())+(wGapRate*(wSizeGap/w));
	else if(x<gap)	wPst=0;
	else if(x>w-gap) wPst=wSizeGap;

	if(y>gap && y<h-gap) hPst=y*(img.height()/h)-(hRate*zoom.height())+(hGapRate*(hSizeGap/h));
	else if(y<gap)	hPst=0;
	else if(y>h-gap) hPst=hSizeGap;

	img.css({top:-hPst+'px',left:-wPst+'px'});	
}

function setClickEvt(){
	$('.resultType li').bind('click',function(e){
		$('.resultType li').removeClass('on');
		$(e.currentTarget).addClass('on');
	});
	$('.resultList li').bind('click',function(e){
		$('.resultList li').removeClass('on');
		$(e.currentTarget).addClass('on');
	});
}
