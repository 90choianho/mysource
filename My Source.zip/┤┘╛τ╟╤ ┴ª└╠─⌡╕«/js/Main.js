// JavaScript Document
$(function(){
	/*Main Rolling Banner 전역 변수----------------------------------------------------------------------------------------------------------------------------------------------------------*/
	  var myCJLink = new Array("#","#","#");
	  var myCJImg = new Array("http://www.cj.co.kr/cj_files/main/visual/201503/1427700698192_0.jpg",
	                           "http://www.cj.co.kr/cj_files/main/visual/201503/1427440022001_0.jpg",
							   "http://www.cj.co.kr/cj_files/main/visual/201503/1426662948423_0.jpg"
	                          );
	  var myCJTitle = new Array("cj배너상단따라하기",
	                             "매개변수3개이므로 3개의 array문이 필요하지요",
								 "매개변수를 가진 함수를 setInterval해야해요"
	                            );
								
	  var myCJList="";myCJBtnsList=""; //화면 셋팅을 위한 변수 처리//
	  var count=0; //현재 화면의 보여지고 있는 카운트//
	  var autoSlide; //인터벌을 다른 함수에서도 지우고 생성해야 하기 때문에 전역으로 사용한다//
	/*==================================================================================================================================================================================*/
	//Right Rolling Banner 전역변수=========================================================================================================================================================//
	  var nowIndex = 1;//롤링박스 초기 인덱스//
	  var data = new Array('<a class="abs b1" href="#" data-index="1">이미지1</a>','<a class="abs b2" href="#" data-index="2">이미지2</a>','<a class="abs b3" href="#" data-index="3">이미지3</a>');
	  var preDirect;//롤링박스 이전 이동 방향 저장 변수//
	  var isRolling = true;//자동 롤링 진행 여부 판단 변수 : Bool//
	/*---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
	function init()
	{
		settingGNB();
		settingNewsLetter();
		settingMainBanner();
		settingLGallery();
		settingRightRolling();
		settingFadeBanner();
		productRollingBanner();
		familySiteBanner();
	}
	//Setting GNB//
	function settingGNB()
	{
		$(".gnb").on("mouseenter focusin",function()
		{
			console.log("OVER");
			$(this).stop(true,true).animate({"height":160},500,function(){})
		}).on(" mouseleave focusout",function(){
			$(this).stop(true,true).animate({"height":40},500,function(){})
		});
	}
	//Setting MainRolling Banner , FUNCS========================================================================================================================================================//
	function settingMainBanner()
	{
	  for(var i=0; i<myCJTitle.length; i++)
	  {
		  myCJList += "<a href=" + myCJLink[i] + " data-index="+ i + "><img src="+myCJImg[i]+" /></a>";
		  myCJBtnsList += "<a href='#none'></a>";
	  }
	  $(".cjTrain").html(myCJList).width($(".cjTrain a img").width()*myCJTitle.length);
	  $(".btns").html(myCJBtnsList);
	  //btns 버튼 등록//
	  $(".btns a").each(function(index,element){
		  $(this).data("index",index);
		  $(this).click(function(){
			  clearInterval(autoSlide);
			  slideCJ($(this).data('index'));
			  mySlideAni2($(this).data('index'));
		  });
	  });
	  
	  //좌우 버튼 등록//
	  $(".arrowBtn a").click(function(){
		  var direct = parseInt($(this).attr("data-direct"));
		  var goCount =count+direct;
		  if(goCount < 0)
		  {
			  goCount = myCJTitle.length -1;
		  }
		  else if(goCount > myCJTitle.length -1)
		  {
			  goCount = 0;
		  }
		  clearInterval(autoSlide);
		  slideCJ(goCount);
		  mySlideAni3(goCount,direct);
	  });
	  
	  slideCJ(count);//1회 실행//
	  autoSlide = window.setInterval(function(){
		  count++;count=count%myCJTitle.length;slideCJ(count);
		  mySlidAni();
	  },3000);
	}
	//END SETTING Main Rolling Banner============================================================================================================================================================//
	  function slideCJ(a){
        $(".num").html("0"+(a+1));
	    $(".title").html(myCJTitle[a]);
		$(".btns a").removeClass("act");
		$(".btns a:eq("+a+")").addClass("act");
	  }
	  //SLIDE AUTO//
	  function mySlidAni(){
		  $(".cjTrain").animate({marginLeft:-$(".cjTrain a").width() + parseInt($(".cjTrain").css("margin-left"))},500,function(){
			  $("a:first",this).appendTo(this);
			  $(this).css("margin-left",0);
		  });
	  }
	  //버튼을 누르면 동작함 MANUAL//
	  function mySlideAni2(index){
		  if(count > index) //전 요소를 보여줄때//
		  {
			 $(".cjTrain a[data-index=\""+index+"\"]").insertBefore($(".cjTrain a[data-index=\""+count+"\"]")); //보여질 요소를 현재 보여지는 요소 앞에 넣어둔다//
			 $(".cjTrain").css("margin-left",-$(".cjTrain a").width() + parseInt($(".cjTrain").css("margin-left"))); //왼쪽에서 우측으로 이동하므로 미리 이동 시킨다//
			  $(".cjTrain").animate({marginLeft:+$(".cjTrain a").width() + parseInt($(".cjTrain").css("margin-left"))},500,function(){ //이동//
				  $(this).css("margin-left",0); //원래 원점으로 이동//
				  resetAlign(index); //이후 이동을 위한 초기화 실행//
			  });
		  }
		  else if(count < index) //후 요소를 보여줄때//
		  {
			 $(".cjTrain a[data-index=\""+index+"\"]").insertAfter($(".cjTrain a[data-index=\""+count+"\"]"));//보여질 요소를 현재 보여지는 요소 뒤에 넣어둔다, 우측에서 왼쪽으로 이동하므로 따로 이동시키지 않는다.//
			  $(".cjTrain").animate({marginLeft:-$(".cjTrain a").width() + parseInt($(".cjTrain").css("margin-left"))},500,function(){ //이동//
				  $(this).css("margin-left",0); //원래 원점으로 이동//
				  resetAlign(index); //이후 이동을 위한 초기화 실행//
			  });
		  }
		  else //같은 값을 선택하면 동작할 필요가 없다//
		  {
			  autoSlide = window.setInterval(function(){count++;count=count%myCJTitle.length;slideCJ(count);mySlidAni(); },3000);
		  }
		  count = index;
	  }
	  //Arrow버튼을 누르면 동작함 MANUAL//
	  function mySlideAni3(index,direct){
		  if(direct == -1) //전 요소를 보여줄때//
		  {
			 $(".cjTrain a[data-index=\""+index+"\"]").insertBefore($(".cjTrain a[data-index=\""+count+"\"]")); //보여질 요소를 현재 보여지는 요소 앞에 넣어둔다//
			 $(".cjTrain").css("margin-left",-$(".cjTrain a").width() + parseInt($(".cjTrain").css("margin-left"))); //왼쪽에서 우측으로 이동하므로 미리 이동 시킨다//
			  $(".cjTrain").animate({marginLeft:+$(".cjTrain a").width() + parseInt($(".cjTrain").css("margin-left"))},500,function(){ //이동//
				  $(this).css("margin-left",0); //원래 원점으로 이동//
				  resetAlign(index); //이후 이동을 위한 초기화 실행//
			  });
		  }
		  else if(direct == 1) //후 요소를 보여줄때//
		  {
			 $(".cjTrain a[data-index=\""+index+"\"]").insertAfter($(".cjTrain a[data-index=\""+count+"\"]"));//보여질 요소를 현재 보여지는 요소 뒤에 넣어둔다, 우측에서 왼쪽으로 이동하므로 따로 이동시키지 않는다.//
			  $(".cjTrain").animate({marginLeft:-$(".cjTrain a").width() + parseInt($(".cjTrain").css("margin-left"))},500,function(){ //이동//
				  $(this).css("margin-left",0); //원래 원점으로 이동//
				  resetAlign(index); //이후 이동을 위한 초기화 실행//
			  });
		  }
		  else //같은 값을 선택하면 동작할 필요가 없다//
		  {
			  autoSlide = window.setInterval(function(){count++;count=count%myCJTitle.length;slideCJ(count);mySlidAni(); },3000);
		  }
		  count = index;
	  }
	  //배열을 초기화하여 자동 이동에 하는데 무리 없도록 처리한다//
	  function resetAlign(tarIndex){
		  
		  $(".cjTrain a").each(function(index,element){
			  var inputNum = (tarIndex + index)%myCJTitle.length;
			  $(".cjTrain a[data-index=\""+inputNum+"\"]").appendTo($(".cjTrain"));
		  });
		  clearInterval(autoSlide); 
		  autoSlide = window.setInterval(function(){count++;count=count%myCJTitle.length;slideCJ(count);mySlidAni(); },3000);
	  }
	//END Main Rolling Banner FUNCS==================================================================================================================================================================//
	//NEW LETTER ROLLING================================================================================================================================================//
	function settingNewsLetter()
	{
		var newsInput = new Array(["http://test.postvisual.coom/hyunT","긴급보도","양꼬치엔 찡타우","2015.04.01"],
								   ["http://test.postvisual.coom/testPad","공지사항","두르와드루와","2015.04.02"],
								   ["http://test.postvisual.coom/hyunT","뉴스보도","잊으시오!","2015.04.03"]);
		var myNewsList = "";
		var newsDir = 1;
		for(var i=0; i<newsInput.length; i++)
		{
		myNewsList += "<p class='clear'><a href="+newsInput[i][0]+"><span class='fl cate'>"+newsInput[i][1]+"</span><span class='fl subject'>"+newsInput[i][2]+"</span></a><span class='fr date'>"+newsInput[i][3]+"</span></p>";
		}
		$(".adNews").html(myNewsList);
		function myNewsAni(nDir)
		{
			$(".adNews:not(:animated)").animate({"marginTop":nDir*parseInt($(".newWrap").height()) + parseInt($(".adNews").css("margin-top"))},500,function(){
				if(nDir>0)
				{
					$("p:last",this).prependTo($(this));
				}
				else
				{
					$("p:first",this).appendTo($(this));
				}
				$(this).css("margin-top",($(".newWrap").height()*-1)+"px");
			});
		}
		$(".adbtns a").click(function(){
			clearInterval(myNewsAuto);
			var nextDir = 1;
			if($(this).hasClass("up"))
			{
				myNewsAni(1);
				nextDir = 1;
			}
			else
			{
				myNewsAni(-1);
				nextDir = -1;
			}
			myNewsAuto = setInterval(function(){
			myNewsAni(nextDir);
			},3000);
		});
		var myNewsAuto = setInterval(function(){
			myNewsAni(newsDir);
		},3000);
	}
	//===================================================================================================================================================================//
	//Setting LeftGallery//
    function settingLGallery()
	{
	   var mygallery="";
	   var mygalleryDB=new Array(["title0","http://www.istarbucks.co.kr/upload/main/20150331175847533.jpg","#","상품설명01"],
	                              ["title1","http://www.istarbucks.co.kr/upload/main/20150318100921222.jpg","#","상품설명02"],
								  ["title2","http://www.istarbucks.co.kr/upload/main/20150318101135167.jpg","#","상품설명03"],
								  ["title3","http://www.istarbucks.co.kr/upload/main/20150331182930886.jpg","#","상품설명04"],
								  ["title4","http://www.istarbucks.co.kr/upload/main/20150318101303819.jpg","#","상품설명05"],
								  ["title5","http://www.istarbucks.co.kr/upload/main/20150318100103353.jpg","#","상품설명06"]	                               
	   );
	   for(var i=0; i<mygalleryDB.length; i++)
	   {
		  mygallery+="<li class=\"g"+i+"\" onclick=location.href=\""+mygalleryDB[i][2]+"\"><p class='rel lgTitle'>"+mygalleryDB[i][0]+"</p><div class='imgs rel'><img src="+mygalleryDB[i][1]+"></div><p class='abs blackbg'>"+mygalleryDB[i][3]+"</p></li>";
		  if(i%3===2)
		  {
		  	mygallery+="<div class='clear'></div>";		
		  }
		}	
	    $(".galleryWrap ul:eq(0)").append(mygallery);
		$(".galleryWrap li").on("mouseenter focusin",function(){
			$("p.blackbg",this).animate({"top":27,"opacity":0.8},500);
		}).on("mouseleave focusout",function(){
			$("p.blackbg",this).animate({"top":270,"opacity":0},500);
		});
	}
	//setting Right Rolling Banner===================================================================================================================================================================//
	function settingRightRolling()
	{
		//버튼 등록//
		$(".right_rolling_btns a").click(function(){
			changeBanner($(this).text(),false,0);
		});
		//양옆 화살표 버튼//
		$(".arrow a").click(function(){
		  var changeIndex = nowIndex + parseInt($(this).attr("data-index"));
		  if(changeIndex < 1)
		  {
			  changeIndex = data.length;
		  }
		  else if(changeIndex > data.length)
		  {
			  changeIndex = 1;
		  }
		  changeBanner(changeIndex,false,parseInt($(this).attr("data-index")));
		});
		
		$(".rolling").on("mouseenter focusin",function(){
			isRolling = false;
		});
		$(".rolling").on("mouseleave focusout",function(){
			isRolling = true;
		});
		
		startRightRollingBanner();
	}
	//Right Rolling Banner FUNC=============================================================================================================================================================================//
	function changeBanner(index,isAuto,isArrow)
	{
		var direct;
		var useIndex = parseInt(index);
		if(isAuto == false)
		{
			if(isArrow == 0)
			{
				if(nowIndex > useIndex)
				{
					direct = -1;
				}
				else if(nowIndex < useIndex)
				{
					direct = 1;
				}
				else
				{
					return false;
				}
			}
			else
			{
				direct = isArrow;
			}
		}
		else
		{
			direct = 1;
		}
		if(direct == 1)
		{	
			if($(".imgTrain").children().length > 1 && $(".imgTrain a").eq(1).attr("data-index") != useIndex)
			{
				if(preDirect != direct)
				{
					$(".imgTrain a").eq(1).remove();
				}
				else{
					$(".imgTrain a").eq(0).remove();
				}
				$(".imgTrain").append(data[useIndex-1]);
				$(".imgTrain a").eq(1).css("left",(parseInt($(".imgTrain a").eq(0).css("width"))*1)+"px");

			}
			else if($(".imgTrain").children().length == 1)
			{
				$(".imgTrain").append(data[useIndex-1]);
			    $(".imgTrain a").eq(1).css("left",(parseInt($(".imgTrain a").eq(0).css("width"))*1)+"px");
			}

			$(".imgTrain a").each(function(index){
				$(this).animate({"left":parseInt($(this).css("width"))*(index-1)},500,function(){});
			});
		}
		else
		{
			if($(".imgTrain").children().length > 1 && $(".imgTrain a").eq(0).attr("data-index") != useIndex)
			{
				if(preDirect != direct)
				{
					$(".imgTrain a").eq(0).remove();
				}
				else
				{
					$(".imgTrain a").eq(1).remove();
				}
				
				$(".imgTrain").prepend(data[useIndex-1]);
			    $(".imgTrain a").eq(0).css("left",(parseInt($(".imgTrain a").eq(0).css("width"))*-1)+"px");
			}
			else if($(".imgTrain").children().length == 1)
			{
				$(".imgTrain").prepend(data[useIndex-1]);
			    $(".imgTrain a").eq(0).css("left",(parseInt($(".imgTrain a").eq(0).css("width"))*-1)+"px");
			}
			$(".imgTrain a").each(function(index){
				$(this).animate({"left":parseInt($(this).css("width"))*(index)},500,function(){});
				//$(this).css("left",(parseInt($(this).css("width"))*(index)) + "px");
			});
		}
		nowIndex = useIndex;
		preDirect = direct;
	}
	
	//롤링배너 셋팅 Func//
	function startRightRollingBanner()
	{
		$(".imgTrain").html("");
		$(".imgTrain").append(data[0]);
		$(".imgTrain a").eq(0).css("left","0px");
		
		autoRolling();
		
	}
	//자동 롤링//
	function autoRolling()
	{
	  if(isRolling)
	  {
		   var changeIndex = nowIndex +1;
		  if(changeIndex < 1)
		  {
			  changeIndex = data.length;
		  }
		  else if(changeIndex > data.length)
		  {
			  changeIndex = 1;
		  }
	 	 changeBanner(changeIndex,true,0);
	  }
		window.setTimeout(autoRolling,"4000");
	}
	//RightRollingBanner FUNC END==============================================================================================================================================//
	//FadeBanner=================================================================================================================================================================//
	function settingFadeBanner()
	{
		var fadeImgArr = new Array(["#","http://www.cj.co.kr/cj_files/brand/201501/1420762498187_0.jpg","상품소개0"],
								 ["#","http://www.cj.co.kr/cj_files/brand/201402/1393234598400_0.jpg","상품소개1"],
								 ["#","http://www.cj.co.kr/cj_files/brand/201402/1391665884023_0.jpg","상품소개2"]
								 );
		var fadeImgs = "";
		var fadeCount = 0;
		var fadeInterval;
		var isAutoPlay = true;
        function fadeBannerChange(fadeCount){
			fadeImgs = "<a href="+fadeImgArr[fadeCount][0]+" ><img src="+fadeImgArr[fadeCount][1]+"></a>";
			$(".fadeImg").prepend(fadeImgs);
			$(".addFadePage span span").html(fadeCount+1);
			$(".addFadeTitle a").html(fadeImgArr[fadeCount][2]).attr("href",fadeImgArr[fadeCount][0]);
			
		}
		function fadeAnimationFn(){
				$(".fadeImg a:last").animate({"opacity":0},500,function(){
				$(this).remove();
			});
		}
        fadeBannerChange(fadeCount);//화면이 열리면 1회실행//
	    $(".addFadePage span span").after("/"+fadeImgArr.length);
		fadeInterval = window.setInterval(function(){
			fadeCount++;
			fadeCount = fadeCount%fadeImgArr.length;
			fadeBannerChange(fadeCount);
			fadeAnimationFn();
			},3000);
		
		$(".fadeBtns").click(function(e){
			clearInterval(fadeInterval);
			if($(this).hasClass("lbtn"))
			{
				fadeCount--;
				if(fadeCount < 0)
				{
					fadeCount = 2;
				}
				fadeCount = fadeCount%fadeImgArr.length;
				fadeBannerChange(fadeCount);
				fadeAnimationFn();
				$(".toggle").html("Play");
				isAutoPlay = false;
			}
			else if($(this).hasClass("rbtn"))
			{
				fadeCount++;
				fadeCount = fadeCount%fadeImgArr.length;
				fadeBannerChange(fadeCount);
				fadeAnimationFn();
				$(".toggle").html("Play");
				isAutoPlay = false;
			}
            
			if($(this).hasClass("toggle"))
			{
				if(isAutoPlay == false)
				{
					$(this).html("Stop");
					fadeInterval = window.setInterval(function(){
					fadeCount++;
					fadeCount = fadeCount%fadeImgArr.length;
					isAutoPlay = true;
					fadeBannerChange(fadeCount);
					fadeAnimationFn();
					},3000);
				}
				else
				{
					isAutoPlay = false;
					$(this).html("Play");
				}
			}
		});				
	}
	//PRODUCT ROLLING=================================================================================================================================================================//
	function productRollingBanner()
	{
		  var productDBArr=new Array(["#","http://www.cj.co.kr/cj_files/product/201502/1424137867155_0.jpg","images/1385353113778_0.png","상품명0"],
							  ["#","http://www.cj.co.kr/cj_files/product/201501/1420422939767_0.jpg","images/1385356752298_0.png","상품명1"],
							  ["#","http://www.cj.co.kr/cj_files/product/201502/1424137846460_0.jpg","images/brand_img.png","상품명2"],
							  ["#","http://www.cj.co.kr/cj_files/product/201411/1416528785839_0.jpg","images/1385353113778_0.png","상품명3"],
							  ["#","http://www.cj.co.kr/cj_files/product/201412/1418202030330_0.jpg","images/1385356752298_0.png","상품명4"],
							  ["#","http://www.cj.co.kr/cj_files/product/201503/1426478769447_0.jpg","images/brand_img.png","상품명5"],
							  ["#","http://www.cj.co.kr/cj_files/product/201411/1416528785839_0.jpg","images/1385353113778_0.png","상품명3"]
							  );
		 var productViewCount = 2; 
		 var productFocusNum = 3;//가운데 위치할 카운트 처리//
		 var productInterval;
		 var productMDir = 1;
		 var defaultProductMarginL;
		 var isAuto = true;
		 
		 function settingBanner()//배너 셋팅
		 {
			 var htmlForProductItem = "";
			 for(var i=0; i<productDBArr.length; i++)
			 {
				 htmlForProductItem += "<a href="+productDBArr[i][0]+"><img src="+productDBArr[i][1]+" alt="+productDBArr[i][3]+"/></a>";
			 }
			 $(".product_item").html(htmlForProductItem);
			 $(".product_item a").eq(productFocusNum).css({"margin-top":5,"width":100});
			 defaultProductMarginL = parseInt($(".product_item").css("margin-left")) - ($(".product_item a").eq(0).width() + parseInt($(".product_item a").eq(0).css("margin-left")));
			 $(".product_item").css("margin-left",defaultProductMarginL);
			 productInterval = setInterval(changeBanner,3000,productMDir);
			 $(".product_btn").click(function(e){
				 clearInterval(productInterval);
				 if($(this).hasClass("product_btn_l"))
				 {
					 productMDir = -1;
					 changeBanner();
					 productInterval = setInterval(changeBanner,3000);
				 }
				 else
				 {
					 productMDir = 1;
					 changeBanner(); 
					 productInterval = setInterval(changeBanner,3000);
				 }
			 });
			 $(".product_toggle").click(function(e)
			 {
				 clearInterval(productInterval);
				 if(isAuto == false)
				 {
					  isAuto = true;
					  $(this).html("STOP");
					  productInterval = setInterval(changeBanner,3000,productMDir);
				 }
				 else
				 {
					 $(this).html("PLAY");
					 isAuto = false;
				 }
			 });
			 changeItemText();
		 }
		 function changeItemText()//하단 브랜드 상품명 변경//
		 {
			 $(".brandlogo img").css("display","none").attr("src",productDBArr[productViewCount][2]).css("display","block");
			 $(".product_name span").css("display","none").html(productDBArr[productViewCount][3]).fadeIn("slow",function(){
		     });
		 }
		 function changeBanner()// 배너 이동 모션//
		 {
			 productViewCount += productMDir;
			 if(productViewCount < 0)
			 {
				 productViewCount = productDBArr.length-1;
			 }
			 productViewCount = productViewCount%productDBArr.length;
			 changeItemText();
			 //CSS Transition 사용
			 //$(".product_item a").eq(productFocusNum).removeClass("act");
			// $(".product_item a").eq(productFocusNum+productMDir).addClass("act");
			//Jquery Animate 사용
			$(".product_item a").eq(productFocusNum).animate({"width":70,"marginTop":20},400); 
			$(".product_item a").eq(productFocusNum+productMDir).animate({"width":100,"marginTop":5},400); 
			 var movSpace = defaultProductMarginL + (($(".product_item a").eq(0).width() + parseInt($(".product_item a").eq(0).css("margin-left")))*(productMDir*-1));
			 $(".product_item").animate({"marginLeft":movSpace},400,"easeInOutSine",function(){
				 if(productMDir == 1)
				 {
				   $("a:first",this).appendTo($(this));
				 }
				 else
				 {
				   $("a:last",this).prependTo($(this));
				 }
				 $(this).css("margin-left",defaultProductMarginL);
			 });
			 
		 }
		 settingBanner();
	}
	//PRODUCT ROLLING END==============================================================================================================================================================//
	//FamilySite=================================================================================================================================================================//
    function familySiteBanner()
	{
		var moveNum = 5;
		var family=new Array();
			 family[0]="패밀리1";
			 family[1]="패밀리2";
			 family[2]="패밀리3";
			 family[3]="패밀리4";
			 family[4]="패밀리5";
			 family[5]="패밀리6";
			 family[6]="패밀리7";
			 family[7]="패밀리8";
			 family[8]="패밀리9";
			 family[9]="패밀리10";
			 family[10]="패밀리11";
			 family[11]="패밀리12";
			 family[12]="패밀리13";
			 family[13]="패밀리14";
			 family[14]="패밀리15";
			 family[15]="패밀리16";
			 family[16]="패밀리17";
			 family[17]="패밀리18";
			 family[18]="패밀리19";
			 
		var familyGroup="";
		for(var i=0; i<family.length; i++)
		{
			familyGroup+="<a href='#'>"+family[i]+"</a>";
		}
		$(".familyTrain").append(familyGroup);
		
		var count=0;
		var moveAuto=setInterval(function(){moveAD(-1*moveNum)},3000); //실행문
	
		
		function moveAD(dir)
		{
			var movingBannerW = dir*($(".familyTrain a").width()+(parseInt($(".familyTrain a").css("margin-left"))*2))+parseInt($(".familyTrain").css("margin-left"));
			$(".familyTrain:not(:animated)").animate({"marginLeft":movingBannerW},500,function(){
				if(dir < 0)
				{ 
				    for(var i=0; i<dir*-1; i++)
					{
						$("a",this).eq(0).appendTo($(this));
					}
					//$("a:nth-child(-n+"+(dir*-1)+")",this).appendTo($(this)); //앞에서 부터 이동 범위 만큼 선택하여 뒤에 붙임//7버전 nth-child 지원 안됨//
				}
				else
				{//그 봉지속의 첫번째a를 그 봉지안에서 맨뒤로옮기고,
					//$("a:nth-last-child(-n+"+dir+")",this).prependTo($(this)); //뒤에서 부터 이동 범위 만큼 선택하여 뒤에 붙임//7버전 nth-child 지원 안됨//
					for(var i=0; i<dir; i++)
					{
						$("a",this).eq(family.length-1).prependTo($(this));
					}
				}
				$(this).css("margin-left",Math.abs(dir)*-1*($(".familyTrain a").width()+(parseInt($(".familyTrain a").css("margin-left"))*2))); //그 빈자리가 생기므로 봉지를 원래자리로 돌린다
			});
		}
		
		$(".familyTrain a").on("mouseenter focusin",function(){
			clearInterval(moveAuto);
		}).on("mouseleave",function(){
			 moveAuto=setInterval(function(){moveAD(-1*moveNum)},3000); 			
		});
		
		$(".familyBtn").click(function(){
			clearInterval(moveAuto);
			switch($(this).hasClass("btnr"))
			{
				case true:
				  moveAD(-1*moveNum);
				break;
				case false:
				  moveAD(1*moveNum);
				break;
			}
			moveAuto=setInterval(function(){moveAD(-1*moveNum)},3000); 	
		});
		   
	   $(".familyTrain").width(($(".familyTrain a").width() + parseInt($(".familyTrain a").css("margin-left"))*2)*family.length); //Family Site의 개수 * (FamilySite 넓이 + FamilySite마진*2) 로 부모 Width값 설정
	   //$("a:nth-last-child(-n+"+moveNum+")",$(".familyTrain")).prependTo($(".familyTrain")); //1번부터 나오게 처리// (좌우 이동을 위한 처리를 위한 초기 값 설정)//nth-last-child 7에서 사용 불가//
	   for(var i=0; i<moveNum; i++)
	   {
		 $("a",$(".familyTrain")).eq(family.length-1).prependTo($(".familyTrain"));  
	   }
	   $(".familyTrain").css("margin-left",moveNum*-1*($(".familyTrain a").width()+(parseInt($(".familyTrain a").css("margin-left"))*2)));
	}
	//FamilySite END=================================================================================================================================================================//
	init();
});
