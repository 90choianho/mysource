( function ( jQuery ) {

// 공통객체
var commonObj = {
	jQuery: jQuery,
	isLogged: ( typeof usr_login_yn == 'undefined' ) ? false : ( usr_login_yn == 'Y' ),
	$window: $ ( window ),
	$document: $ ( document ),
	queryString: CJOSCommon.util.getQueryString ()
};


// 시작 뷰컨트롤러
var CJOSCjmallMainViewController = ( function ( commonObj ) {
	
	var $ = commonObj.jQuery,
		instance;
		

	function CJOSCjmallMain () {
		var that = this;
		that.init ();
	}
	CJOSCjmallMain.prototype = {
		init: function () {
			var bigBanner = new BigBannerContoller ( commonObj ),
				rollingBanner = new CircularRollingController ( commonObj ),
				todayDeal = new TodayRecommendDeal ( commonObj );
		}
	}
	
	return {
		getInstance: function () {
			if ( instance === undefined ) {
				instance = new CJOSCjmallMain ( commonObj );
			}
			return instance;
		}
	}
} ) ( commonObj );

// 핫딜영역
var BigBannerContoller = function ( commonObj ) {
	var $ = commonObj.jQuery,
		$wnd = commonObj.$window,
		$doc = commonObj.$document,
		$wrapper,
		$contentWrapper,
		$thumbContainer,
		$thumbOnBox,
		$paging,
		curSumIndex = 0,
		thumbNumPerPage = 10,
		thumbWidth = 98,
		thumbDuration = 500,
		transform = CJOSCommon.util.transformProp,
		transition = CJOSCommon.util.transtionProp,
		isFirefox = CJOSCommon.util.browser.isFirefox,
		isWinSafari = CJOSCommon.util.browser.isWinSafari,
		useTransition = ( !isWinSafari && !isFirefox && transition && transform ),
		//customCss = new CJOSCommon.css (),
		lazyLoadCount = 0,
		lazyLoadImgArr = [],
		thumbTimer = null;

	function init () {
		$wrapper = $ ( '.main_contents .showcase' );

		var contentMoveType = 'fadeExtend',
			contentDuration = 700,
			contentEase = 'easeOut';
		
		$contentWrapper = $wrapper.find ( '.bigbanner_wrap > ul' );
		$thumbContainer = $wrapper.find ( '.showcase_thumb > ul' );

		$contentWrapper = $contentWrapper.circularRolling ( {
			wrapper: $wrapper,
			nextBtn: $wrapper.find ( '.rolling_btn.next' ),
			prevBtn: $wrapper.find ( '.rolling_btn.prev' ),
			moveType: contentMoveType,
			duration: contentDuration,
			ease: contentEase,
			use3d: false,
			autoRolling: true,
			autoRollingDuration: 3000
		} );

		/*
		customCss.insertRule ( '.circular_slide img.lazy', 'visibility:hidden', 0 );
		if ( useTransition ) {
			customCss.insertRule ( '.circular_slide', 'will-change:transform, opacity', 0 );
		} else {
			customCss.insertRule ( '.circular_slide', 'will-change:left, opacity', 0 );
		}
		*/
		
		/*
		var $slides = $contentWrapper.getSlides ();
		lazyLoadCount = $slides.length;
		for ( var i = 0; i < lazyLoadCount; i++ ) {
			var $slide = $slides [ i ],
				$img = $slide.find ( 'a > p > img' ),
				src = $img.attr ( 'src' );
			
			if ( i > 0 ) {
				$img.attr ( { 'src': '', 'data-src': src } );
				$img.addClass ( 'lazy' );
			}
			lazyLoadImgArr.push ( $img );
		}
		lazyLoadCount--;
		*/
		
		$thumbContainer = $thumbContainer.circularRolling ( { 
			viewNum: thumbNumPerPage,
			isPreventDefault: false,
			duration: 0,
			selectEventType: 'mouseenter'
		} );
		var $curThumbSlide = $thumbContainer.getSlide ( $thumbContainer.currentSlideIndex );
		if ( $curThumbSlide ) {
			$curThumbSlide.addClass ( 'on' );
		}
		
		$thumbOnBox = $thumbContainer.next ();
		$paging = $wrapper.find ( '.paging > a' );
	}

	function addEventListeners () {
		$contentWrapper.on ( 'beforeMove', contentBeforeMoveHn );
		$thumbContainer.on ( 'itemSelect pageChange', thumbContorlHn );
		$thumbContainer.on ( 'beforeMove', thumbAfterHn );

		$paging.on ( 'mouseenter', pagingHn );
		pagingUpdate ( 0 );
	}

	function moveToPrevSlide () {
		$contentWrapper.prevSlide ();
	}

	function moveToNextSlide () {
		$contentWrapper.nextSlide ();
	}

	function checkLazyLoad ( index ) {
		var $img = lazyLoadImgArr [ index ];
		if ( $img.hasClass ( 'lazy' ) ) {
			$img.attr ( 'src', $img.attr ( 'data-src' ) );
			$img.removeClass ( 'lazy' );
		}
		lazyLoadCount--;
	}

	function setThumb ( index ) {
		$thumbContainer.moveTo ( index );
		var posX = ( index % thumbNumPerPage ) * thumbWidth;
		// 3d transform이 겹쳐서 transition이 되면 겹친 transform 애니메이션이 작동안되는 경우가 있음
		/*if ( useTransition ) { 
			var moveCss = {};
			moveCss [ transform ] = 'translate3d(' + posX + 'px,0px,0px)';
			moveCss [ transition ] = transform + ' ' + 700 + 'ms ease';
			$thumbOnBox.css ( moveCss );
		} else {
			$thumbOnBox.stop ().animate ( { left: posX }, thumbDuration );
		}*/
		if ( curSumIndex == index  ) {
			return;
		}
		curSumIndex = index;
		$thumbOnBox.stop ().css ( { zIndex: 100 } ).animate ( { left: posX }, thumbDuration, function () {
			$thumbOnBox.css ( { zIndex: 1 } );
		} );
	}

	function contentBeforeMoveHn ( e ) {
		//checkLazyLoad ( e.index );
		setThumb ( e.index );
	}

	function thumbContorlHn ( e ) {
		switch ( e.type ) {
			case 'pageChange':
				pagingUpdate ( e.pageIndex );
				break;
			case 'itemSelect':
				//$contentWrapper.moveTo ( e.index );
				if ( thumbTimer ) {
					clearTimeout ( thumbTimer );
					thumbTimer = null;
				}
				setThumb ( e.index );
				thumbTimer = setTimeout ( function () { 
					$contentWrapper.moveTo ( e.index );
				}, 200 );
				break;
		}
	}

	function thumbAfterHn ( e ) {
		var $currentTarget = e.$currentTarget,
			$beforeSlide = $currentTarget.getSlide ( e.beforeIndex ),
			$slide = $currentTarget.getSlide ( e.index );
		
		$beforeSlide.removeClass ( 'on' );
		$slide.addClass ( 'on' );
	}

	function pagingHn ( e ) {
		e.preventDefault ();
		/*if ( $contentWrapper.isMoving () ) {
			return;
		}*/
		var $target = $ ( this ),
			index = $target.index (),
			itemIndex = index * thumbNumPerPage;
		
		pagingUpdate ( index );
		$contentWrapper.moveTo ( itemIndex );
	}

	function pagingUpdate ( index ) {
		$paging.removeClass ( 'on' );
		$paging.eq ( index ).addClass ( 'on' );
	}
	
	init ();
	addEventListeners ();
};

// 롤링배너 컨트롤러
var CircularRollingController = function ( commonObj ) {
	var $ = commonObj.jQuery,
		$wnd = commonObj.$window,
		$doc = commonObj.$document,
		rollingsArr = [];

	function init () {
		var $rollings = $ ( '.circularRolling' ),
			contentMoveType = 'fade',
			contentDuration = 700,
			contentEase = 'easeOut';

		for ( var i = 0, len = $rollings.length; i < len; i++ ) {
			var $rolling = $rollings.eq ( i ),
				$wrapper = $rolling.find ( '> ul' ),
				$next = $rolling.find ( '.rolling_btn.next' ),
				$prev = $rolling.find ( '.rolling_btn.prev' ),
				wrapperW = $wrapper.width (),
				startAt = 0;
			
			var isRandomStartAt = ( $rolling.hasClass ( 'mini_mall' ) || $rolling.hasClass ( 'weekly_power' ) );
			if ( isRandomStartAt ) {
				var totalListLen = $rolling.find ( 'li' ).length;
				startAt = Math.floor ( totalListLen * Math.random () );
			}

			$wrapper.circularRolling ( {
				slidesSelector: '> li',
				nextBtn: $next,
				prevBtn: $prev,
				moveWidth: wrapperW,
				moveType: contentMoveType,
				duration: contentDuration,
				ease: contentEase,
				startAt: startAt
			} );

			rollingsArr.push ( $wrapper );
		}
	}

	init ();
};

// 오늘의 추천 딜
var TodayRecommendDeal = function ( commonObj ) {
	var $ = commonObj.jQuery,
		todayTab = $('.today_deal .deal_title li'),
		todayCont = $('.today_deal .deal_list');
		
	todayTab.removeClass('on');
	todayTab.eq(0).addClass('on');
	todayCont.hide();
	todayCont.eq(0).show();
		
	todayTab.each(function(i){
		$(this).mouseover(function(){
			todayTab.removeClass('on');
			todayTab.eq(i).addClass('on');
			todayCont.hide();
			todayCont.eq(i).show();
		});
	});	
	$('.today_deal .deal_title li a').click(function(){return false});
};

// doc ready
commonObj.$document.ready ( function () {
	var main = CJOSCjmallMainViewController.getInstance ();
} );


} ) ( jQuery ); // jQuery