var CJOSCommon = {};

CJOSCommon.util = {};
CJOSCommon.util.scopeBind = function ( context, fn ) {
	return function () {
		fn.apply ( context, arguments );
	}
};
CJOSCommon.util.browser = ( function () {
		var obj = {},
			ua = navigator.userAgent.toLowerCase();

		var isIE = false,
			ieVesion = 0;
		if ( /\bmsie\b/i.test ( ua ) ) {
			ieVesion = parseInt ( ua.match ( /\bmsie (\d+)/i ) [ 1 ] );
		}
		obj.isIE = isIE
		obj.ieVersion = ieVesion;
		obj.tridentVersion = ( /trident\/\d\.\d/.test ( ua ) ) ? ua.match ( /trident\/\d\.\d/ ).join ( '' ).replace ( /trident\//g, '' ) : 0;
		obj.isWinSafari = !!( ua.indexOf ( 'safari/' ) !== -1 && ua.indexOf ( 'windows' ) !== -1 && ua.indexOf ( 'chrome' ) === -1 );
		obj.isFirefox = ua.indexOf ( 'firefox' ) > -1;
		
		return obj;
} ) ();
CJOSCommon.util.getQueryString = function () {
	var qs = window.location.search.length > 0 ? window.location.search.substring ( 1 ) : '',
		args = {},
		items = qs.length ? qs.split ( '&' ) : [],
		item = null,
		name = null,
		value = null;

	for ( var i = 0, len = items.length; i < len; i++ ) {
		item = items [ i ].split ( '=' );
		name = decodeURIComponent ( item [ 0 ] );
		value = decodeURIComponent ( item [ 1 ] );

		if ( name.length ) {
			args [ name ] = value;
		}
	}
	return args;
};
//	vendor prefix check ( transition, transform )
CJOSCommon.util.getVendorPropertyName = function ( div, prop ) {
	// Handle unprefixed versions (FF16+, for example)
	if ( prop in div.style ) {
		return prop;
	}

	var prefixes = [ 'Moz', 'Webkit', 'O', 'ms' ];
	var prop_ = prop.charAt ( 0 ).toUpperCase () + prop.substr ( 1 );
	if ( prop in div.style ) {
		return prop;
	}
	for ( var i = 0; i < prefixes.length; i++ ){
		var vendorProp = prefixes[i] + prop_;
		if ( vendorProp in div.style ) {
			return vendorProp; 
		}
	}
};
CJOSCommon.util.has3d = function () {
	var el = document.createElement ( 'p' ), 
		has3d,
		transforms = {
			'webkitTransform': '-webkit-transform',
			'OTransform': '-o-transform',
			'msTransform': '-ms-transform',
			'MozTransform': '-moz-transform',
			'transform': 'transform'
		};

	// Add it to the body to get the computed style.
	document.body.insertBefore ( el, null );
	for ( var t in transforms ) {
		if ( el.style [ t ] !== undefined ) {
			el.style [ t ] = 'translate3d(1px,1px,1px)';
			has3d = window.getComputedStyle ( el ).getPropertyValue ( transforms [ t ] );
		}
	}
	document.body.removeChild ( el );
	return ( has3d !== undefined && has3d.length > 0 && has3d !== 'none' );
};
CJOSCommon.util.transformProp = ( function () {
	var div = document.createElement ( 'div' ),
		transform = CJOSCommon.util.getVendorPropertyName ( div, 'transform' );
	div = null;
	return transform;
} ) ();
CJOSCommon.util.transtionProp = ( function () {
	var div = document.createElement ( 'div' ),
		transition = CJOSCommon.util.getVendorPropertyName ( div, 'transition' );
	div = null;
	return transition;
} ) ();
CJOSCommon.util.transtionendName = ( function () {
	var	isWinSafari = CJOSCommon.util.browser.isWinSafari,
		prefixes = [ '', 'moz', 'webkit', 'o', 'ms' ],
		eventName = '';

	for ( var i = 0; i < prefixes.length; i++ ){
		var vendor = prefixes[i],
			event = 'on' + vendor + 'transitionend';
		
		if ( event in window ) {
			eventName = ( ( vendor ) ? vendor + 'T' : 't' ) + 'ransition' + ( ( vendor && isWinSafari ) ? 'End' : 'end' );
			break;
		}
	}
	return eventName;
} ) ();
// gnb
CJOSCommon.GNB = function () {
	//gnb
	var firstMenu = $('.big_menu > li > a'),
		firstMenuWrap = $('.big_menu'),
		indivisualSubmenu = $('.big_menu li dl'),
		subMenu = $('.sub_menu'),
		seeAllBtn = $('.gnb .see_all');
		
	firstMenu.each(function(i){
		$(this).mouseenter(function(){
			subMenu.hide();
			seeAllBtn.removeClass('on');
			indivisualSubmenu.hide();
			$(this).next(indivisualSubmenu).show();
		
		});
		
		$('.gnb').mouseleave(function(){
			indivisualSubmenu.hide();
			subMenu.hide();
			seeAllBtn.removeClass('on');
		});

		seeAllBtn.click(function(){
			if (seeAllBtn.hasClass('on') == true){
				subMenu.hide();
				seeAllBtn.removeClass('on');
			}else{
				seeAllBtn.addClass('on');
				indivisualSubmenu.hide();
				subMenu.show();
			}
			return false;
		});
		
	});
	//util
	var utilMenu = $('.util .has_sub'),
		utilMenuTit = $('.util .has_sub > a'),
		utilSub = $('.has_sub ul');
		
		utilMenu.mouseenter(function(){
			$(this).find(utilSub).show();
			$(this).find(utilMenuTit).addClass('on');
		}).focusin(function(){
			$(this).find(utilSub).show();
			$(this).find(utilMenuTit).addClass('on');
		});
		utilMenu.mouseleave(function(){
			utilSub.hide();
			utilMenuTit.removeClass('on');
		});
		$('h1 a').focusin(function(){
			utilSub.hide();
			utilMenuTit.removeClass('on');
		});

	// onAir image
	var onair_img = $(".tv_live  .tv_img img");
	var d = 1000;
	var d1 = 5000;
	var d2 = 5000;
	var d3 = 5000;
	var d4 = 5000;
	var d5 = 5000;
	var da = d + d1 + d2 + d3 + d4 + d5;
	var ani = function(){
		var a1 = {
			marginLeft:-64,
			width:200};
		var a2 = {
			marginTop:-92};
		var a3 = {
			marginLeft:0};
		var a4 = {
			marginTop:-28};
		var a5 = {
			width:136};
		onair_img.delay(d).animate(a1, d1, 'easeInOutCubic').animate(a2, d2, 'easeInOutCubic').animate(a3, d3, 'easeInOutCubic').animate(a4, d4, 'easeInOutCubic').animate(a5, d5, 'easeInOutCubic');
	}
	ani();
	setInterval(ani, da);

	// 이벤트배너
	var $eventBannerWrap = $ ( '.header_event' ),
		$eventBanner = $eventBannerWrap.find ( '.event_wrap > ul' ).circularRolling ( {
			nextBtn: $eventBannerWrap.find ( '.btn_next > a' ),
			prevBtn: $eventBannerWrap.find ( '.btn_prev > a' ),
			slidesSelector: '> li',
			moveWidth: 160,
			duration: 0
		} );

	// rightwing
	var utilWing = new CJOSCommon.UtilWing ();
	

}

// css by javascript
/*
CJOSCommon.css = function () {
	this.style = null;
	this._init ();
}
CJOSCommon.css.prototype = {
	_init: function () {
		var s = this,
			style = document.createElement ( 'style' );

		// Add a media (and/or media query) here if you'd like!
		// style.setAttribute("media", "screen")
		// style.setAttribute("media", "only screen and (max-width : 1024px)")

		// WebKit hack :(
		style.appendChild ( document.createTextNode ( '' ) );
		document.head.appendChild ( style );

		s.style = style;
		s.sheet = style.sheet;
	},

	insertRule: function ( selector, rules, index ) {
		var s = this,
			sheet = s.sheet;
		if ( 'insertRule' in sheet ) {
			sheet.insertRule ( selector + "{" + rules + "}", index );
		} else if ( 'addRule' in sheet ) {
			sheet.addRule ( selector, rules, index );
		}
	}
}
*/

// Util wing
CJOSCommon.UtilWing = function () {
	var minWidth = 1070,
		$window = $ ( window ),
		$footer = $ ( '#cjm_footer' ),
		
		$wrapper = $ ( '.right_wing' ),
		wrapperTop,
		wrapperH,
		wrapperBound,

		$topEvent,
		topEventH,
		
		$followWrap,
		followMarginTop = 10,
		followH,
		followFixedStartPos,
		
		$goTopBtn,
		goBtnMarginTop = 14,
		goBtnBottom = 50,
		goBtnH,
		goBtnBound,
		
		ww = 0,
		wh = 0,
		st = 0;

	function init () {
		if ( $wrapper.length == 0 ) {
			return;
		}
		/*var isLtIE8 = getIsLessThanIE8 ();
		if ( !isLtIE8 ) {
			chkImgLoadComplete ();
		} else {
			$window.on ( 'load', setData );
		}*/
		$window.on ( 'load', setData );
	}

	// IE이고 IE8버전 미만
	function getIsLessThanIE8 () {
		var ua = navigator.userAgent.toLowerCase (),
			reg1 = /\bmsie\b/i,
			reg2 = /trident\/\d\.\d/,
			ver;

		if ( reg1.test ( ua ) ) { // MSIE 인지
			var ieVer = ua.match ( /\bmsie (\d+)/i ) [ 1 ];
			if ( parseInt ( ieVer ) < 8 ) {
				return true; // IE8버전미만
			}
		} else if ( reg2.test ( ua ) ) { // IE 11에서는 MSIE라는 이름이 빠져있다. Trident 사용
			var tridentVer = ua.match ( reg2 ).join ( '' ).replace ( /trident\//g, '' );
			if ( parseInt ( tridentVer ) < 4 ) { 
				return true; // trident 엔진이 4버전미만
			}
		} else {
			// IE아님
		}
		return false;
	}

	function setData () {
		$topEvent = $wrapper.find ( '.top_event' );
		$goTopBtn = $wrapper.find ( '.go_top' );
		$followWrap = $wrapper.find ( '.follow_wrap' );

		wrapperTop = $wrapper.offset ().top;
		
		topEventH = $topEvent.height ();
		goBtnH = $goTopBtn.height ();
		goBtnBound = goBtnMarginTop + goBtnH + goBtnBottom;
		
		followH = $followWrap.outerHeight () + goBtnBound;
		followFixedStartPos = wrapperTop + topEventH;
		
		wrapperH = $wrapper.outerHeight () + goBtnBound;

		
		storeWindowSize ();
		storeScrollTopPosition ();
		updatePosition ();
		
		$goTopBtn.show ();
		
		addEventListeners ();
	}

	function addEventListeners () {
		$window.on ( 'resize', resizeHn );
		$window.on ( 'scroll', scrollHn );
	}

	function chkImgLoadComplete () {
		var $imgs = $wrapper.find ( 'img' ),
			len = $imgs.length,
			i;
		$imgs.on ( 'load error', function ( e ) {
			len--;
			if ( len == 0 ) {
				setData ();
			}
		} );

		for ( i = 0; i < len; i++ ) {
			var $img = $imgs.eq ( i ),
				src = $img.attr ( 'src' );
			$img.attr ( 'src', src );
		}
	}

	function updatePosition () {
		$wrapper.css ( { display: 'none' } );
		if ( ww < minWidth ) {
			isFollowFixed = false;
			$followWrap.removeAttr ( 'style' );
			$goTopBtn.removeClass ( 'fixed' ).css ( { position: 'absolute', bottom: -1 * ( goBtnBottom + 10 ) } );
		} else {
			var footerOffsetTop, 
				footerVisibleH, // 푸터의 현재 가시영역크기
				displayBound,
				isFollowFixed = false;  // 푸터를 제외한 가시영역크기
			
			footerOffsetTop = $footer.offset ().top;
			footerVisibleH = st + wh - footerOffsetTop; 
			footerVisibleH = ( footerVisibleH < 0 ) ? 0 : footerVisibleH;
			displayBound = wh - footerVisibleH;

			if ( st < followFixedStartPos ) {
				isFollowFixed = false;
				$followWrap.removeAttr ( 'style' );
			} else {
				isFollowFixed = true;
				if ( followH <= displayBound ) {
					$followWrap.css ( { position: 'fixed', top: followMarginTop } );
				} else {
					var adjustH = followH - displayBound;
					$followWrap.css ( { position: 'fixed', top: followMarginTop - adjustH } );
				}
			}
			var compareH = ( isFollowFixed ) ? followH : wrapperH - ( st - wrapperTop );
			if ( compareH <= displayBound ) {
				$goTopBtn.addClass ( 'fixed' ).css ( { position: 'fixed', bottom: goBtnBottom + footerVisibleH } );
			} else {
				$goTopBtn.removeClass ( 'fixed' ).css ( { position: 'absolute', bottom: -1 * ( goBtnBottom + 10 ) } );
			}
		}
		$wrapper.css ( { display: 'block' } );
	}

	function storeWindowSize () {
		ww = $window.outerWidth ();
		wh = $window.outerHeight ();
	}

	function storeScrollTopPosition () {
		st = $window.scrollTop ();
	}

	function resizeHn ( e ) {
		storeWindowSize ();
		updatePosition ();
	}

	function scrollHn ( e ) {
		storeScrollTopPosition ();
		updatePosition ();
	}
	
	init ();
	
	/*장바구니, 쇼핑찜*/
	var hasSubLayer = $('.right_wing .personal_menu > li');
	var SubLayer = $('.basket_wrap');
	/*hasSubLayer.each(function(i){
		$(this).click(function(){
			if(i == 1 || i == 2 ){
				SubLayer.hide();
				$(this).find(SubLayer).show();
			}
			return false;
		});
	});*/
	SubLayer.click(function(){
		SubLayer.hide();
	});
	SubLayer.mouseleave(function(){
		SubLayer.hide();
	});

}

// footer
CJOSCommon.Footer = function () {
	
}

//Search
CJOSCommon.Search = function() {
	var allSearchWrap = $('.search_area'), //검색창 전체
		totalSearch = $('#srch_disp_value'), // 검색 input
		btnClear = $('.btn_delete'), // value 삭제
		searchLayer = $('.search_layer'), // 하단 레이어 전체
		searchTab = $('.search_tit a'), // 인기검색어, 최근검색어탭
		hotRecent = $('.hot_recent_cont'), // 인기검색어, 최근검색어 wrap
		popSearchCont = hotRecent.find('.pop_search'), // 인기검색어 body
		newSearchCont = hotRecent.find('.new_search'), // 최근검색어 body
		autoSearch = $('.auto_search'); // 자동완성cont
 	
	// 검색창 초기화
	var allClose = function() {
		btnClear.hide();
		autoSearch.hide();
		searchLayer.hide();
	}
	
	totalSearch.focus(function() { // 검색 input focus
		if (totalSearch.attr('auto-hide')=='on') {			
			totalSearch.attr('auto-hide','off');
			totalSearch.val('');
			autoSearch.hide();
		}
		if (totalSearch.attr('data-autoComplete')=='off') {
			
			$(this).addClass("active");
			if (totalSearch.val().length==0) {
				searchLayer.show();
				hotRecent.show();
				//hotRecent.find('.search_cont').hide();
				/*popSearchCont.show();
				searchTab.removeClass('on');
				searchTab.eq(0).addClass('on')*/
			} else {
				btnClear.show().click(function(){
				totalSearch.val('');
				allClose();
				totalSearch.attr('data-autoComplete','off')
				totalSearch.focus();
			});
			}
		} else {
			hotRecent.hide();
			btnClear.show().click(function(){
				totalSearch.val('');
				allClose();
				totalSearch.attr('data-autoComplete','off')
				totalSearch.focus();
			});
		}
	});
	
	
	searchTab.each(function(){ // 탭 on, off
		$(this).focus(function(){
			searchTab.removeClass('on')
			$(this).addClass('on')
			hotRecent.find('.search_cont').hide();
			$(this).parent().next(hotRecent.find('.search_cont')).show();
		});
	});
	
	//검색영역 : data-autoComplete 자동완성 on,off 속성
	totalSearch.keyup(function(){
		if(totalSearch.val().length!=0){
			hotRecent.hide();
	
			//autoSearch.show();
			$(this).attr('data-autoComplete','on');
			btnClear.show().click(function(){
				allClose();
				totalSearch.val('');
				$(this).attr('data-autoComplete','off')
				totalSearch.focus();
			});
		} else {
			allClose();
			$(this).attr('data-autoComplete','off')
			totalSearch.focus();
		}		
	});
	if (allSearchWrap.length) {
		$(document).bind("click",function(e){
			if (!$.contains(allSearchWrap[0],e.target) ){
				allClose(); 
				
			}
		});
	}
		

	//기획전 sample
	$('.auto_list li').eq(1).find('a').mouseenter(function(){
		$('.planshop_link').show();
	}).mouseleave(function(){
		$('.planshop_link').hide();
	});
	$('.planshop_link').mouseenter(function(){
		$('.planshop_link').show();
	}).mouseleave(function(){
		$('.planshop_link').hide();
	});	
	
	$('.gnb').focusin(function (e){
		allClose();
	});
	$('h1 a').focusin(function(){
		allClose();
	});
	
	
}

// 간단한 롤링페이지 ( 롤링뷰, 페이징만 있음 )
CJOSCommon.simpleCircularRolling  = function ( wrapperSelector, viewnumPerPage, containerWidth ) {
	if ( !wrapperSelector || !viewnumPerPage || !containerWidth ) {
		alert ( 'require wrapperSelector, viewnumPerPage, containerWidth' );
		return;
	}

	var $wrapper = $ ( wrapperSelector ),
		$container = $wrapper.find ( '.simple-circular-container' )
		$paging = $wrapper.find ( '.simple-circular-paging > a' );
	
	$container = $container.circularRolling ( { 
		viewNum: viewnumPerPage,
		moveWidth: containerWidth,
		isPreventDefault: false,
		slidesSelector: '.simple-circular-item',
		duration: 0
	} );

	$paging.on ( 'click', pagingHn );

	function pagingHn ( e ) {
		e.preventDefault ();
		var $target = $ ( this ),
			index = $target.index (),
			itemIndex = index * viewnumPerPage;
		
		pagingUpdate ( index );
		$container.moveTo ( itemIndex );
	}

	function pagingUpdate ( index ) {
		$paging.removeClass ( 'on' );
		$paging.eq ( index ).addClass ( 'on' );
	}
};

// jQuery Ready
CJOSCommon.globalBind = function () {
	var gnb = new CJOSCommon.GNB ();
	var footer = new CJOSCommon.Footer ();
	var gSearch = new CJOSCommon.Search ();
}

if ( jQuery ) {
	$ ( document ).ready ( CJOSCommon.globalBind );
}

/**
 * custom jquery library
 */

// s : jquery Circular Rolling Component
( function ( $ ) {

var CircularRolling = function ( opts ) {
	var $that = this,
		opts = $.extend ( {}, CircularRolling.defaults, opts );
	
	// 멤버변수 설정
	$that.opts = opts;
	$that.movingFlag = false;
	$that.currentSlideIndex = 0;
	$that.$currentSlide = null;
	$that.slideTotal = 0;
	$that.viewNum = 0;
	$that.rollingTimer = null,

	$that.has3d = CJOSCommon.util.has3d ();
	$that.transform = null;

	if ( opts.use3d && $that.has3d ) {
		$that.transform = CJOSCommon.util.transformProp;
		$that.transition = CJOSCommon.util.transtionProp;
		//$that.transitionEnd = CJOSCommon.util.transtionendName;
	}
	
	// 메소드 바인딩
	switch ( opts.moveType ) {
		case 'simple':
			CircularRolling.method.moveTo = CircularRolling.method.moveToSimple;
			break;
		case 'fade':
			CircularRolling.method.moveTo = CircularRolling.method.moveToFade;
			break;
		case 'fadeExtend':
			CircularRolling.method.moveTo = CircularRolling.method.moveToFadeExtend;
			break;
	    case 'infinite':
			CircularRolling.method.moveTo = CircularRolling.method.moveToInfinite;
			CircularRolling.method.over = CircularRolling.method.overToInfinite;
			CircularRolling.method.out = CircularRolling.method.outToInfinite;
			break;
	}
	$.extend ( $that, CircularRolling.method );

	// 초기화
	$that.init ();
	return $that;
};
CircularRolling.defaults = {
	wrapper: null,
	duration: 700,
	moveWidth: 980,
	moveType: 'simple',
	ease: 'easeOut',
	viewNum: 1,
	slidesSelector: '.circular_slide',
	nextBtn: null,
	prevBtn: null,
	hasCounting: true,
	isPreventEvent: false,
	use3d: true,
	autoRolling: false,
	autoRollingDuration: 10000,
	selectEventType: 'click',
	startAt: 0
};

CircularRolling.method = {
	init: function () {
		var $that = this,
			opts = $that.opts;

		$that.slides = $that.setSlides ( $that.find ( opts.slidesSelector ) );
		$that.slideTotal = $that.slides.length;
		$that.viewNum = opts.viewNum;
		$that.rollingUpdateScope = CJOSCommon.util.scopeBind ( $that, $that.rollingUpdate );

		if ( $that.slideTotal ) {
			var $currentSlide = $that.slides [ $that.currentSlideIndex ];
			if ( !$currentSlide.is ( ':visible' ) ) {
				$currentSlide.css ( { display: 'block' } );
			}
			$that.addEventListeners ();
		}
		if ( opts.startAt && opts.startAt < $that.slideTotal ) {
			$that.moveTo ( opts.startAt, 1, 0 );
		}
	},
	addEventListeners: function () {
		var $that = this,
			opts = $that.opts,
			$nextBtn = opts.nextBtn,
			$prevBtn = opts.prevBtn;
		
		if ( $nextBtn && $prevBtn ) {
			$prevBtn.on ( 'mouseover mouseout click', { $delegateTarget: $that }, $that.prevHn );
			$nextBtn.on ( 'mouseover mouseout click', { $delegateTarget: $that }, $that.nextHn );
			if ( $that.slideTotal < 2 ) {
				$nextBtn.css ( { display: 'none' } );
				$prevBtn.css ( { display: 'none' } );
			} else if ( opts.autoRolling ) {
				$that.rollingStart ();
				if ( opts.wrapper ) {
					opts.wrapper.on ( 'mouseenter mouseleave', { $delegateTarget: $that }, $that.enterLeaveHn );
				} else {
					$that.on ( 'mouseenter mouseleave', { $delegateTarget: $that }, $that.enterLeaveHn );
				}
				
			}
			if ( opts.hasCounting ) {
				$that.on ( 'beforeMove', { $currentTarget: $that }, $that.updateCountingHn );
				var counterStr = '<span class="page_wrap"><strong class="prevnext">' + ( $that.currentSlideIndex + 1 ) + '</strong> / <span class="total">' + $that.slideTotal +'</span></span>',
					$nextCounter = $ ( counterStr ),
					$prevCounter = $nextCounter.clone ();

				$nextBtn.data ( '$current', $nextCounter.find ( '.prevnext' ) );
				$prevBtn.data ( '$current', $prevCounter.find ( '.prevnext' ) );
				
				$nextBtn.find ( '> a' ).prepend ( $nextCounter );
				$prevBtn.find ( '> a' ).append ( $prevCounter );

				$that.$nextBtn = $nextBtn;
				$that.$prevBtn = $prevBtn;
			}
		}
	},
	setSlides: function ( $slides ) {
		var $that = this,
			opts = $that.opts,
			moveType = opts.moveType,
			totalWidth = 0,
			arr = [];

		if ( moveType == 'infinite' || moveType == 'fade' || moveType == 'fadeExtend' ) {
			$slides.css ( { display: 'none', position: 'absolute', top:0, left: 0 } );
		}
		for ( var i = 0, len = $slides.length; i < len; i++ ) {
		    var $slide = $slides.eq ( i ).circularRollingBasicItem ( {
					index: i,
					isPreventDefault: opts.isPreventDefault,
					selectEventType: opts.selectEventType
				} );
			$slide.on ( 'select', { $currentTarget: $that }, $that.slideSelectHn );
			totalWidth += $slide.outerWidth ();
			arr.push ( $slide );
		}
		$that.css ( { width: totalWidth } );
		return arr;
	},
	getSlides: function () {
		return this.slides;
	},
	getSlide: function ( index ) {
		return this.slides [ index ];
	},
	isMoving: function () {
		return this.movingFlag;
	},
	prevSlide: function () {
		var $that = this,
			targetIndex = $that.getTargetIndex ( 'prev' );
		$that.moveTo ( targetIndex, -1 );
	},
	nextSlide: function () {
		var $that = this,
			targetIndex = $that.getTargetIndex ( 'next' );
		$that.moveTo ( targetIndex, 1 );
	},
	rollingStop: function () {
		var $that = this;
		if ( $that.rollingTimer ) {
			clearTimeout ( $that.rollingTimer );
		}
	},
	rollingStart: function () {
		var $that = this,
			duration = $that.opts.autoRollingDuration;
		$that.rollingStop ();
		$that.rollingTimer = setTimeout ( $that.rollingUpdateScope, duration );
	},
	rollingUpdate: function () {
		var $that = this,
			duration = $that.opts.autoRollingDuration;
		$that.nextSlide ();
		$that.rollingTimer = setTimeout ( $that.rollingUpdateScope, duration );
	},
	updateCounting: function ( index ) {
		var $that = this,
			cur = index + 1,
			total = $that.slideTotal;

		$that.$nextBtn.data ( '$current' ).text ( cur );
		$that.$prevBtn.data ( '$current' ).text ( cur );
	},
	moveTo: null,
	moveToSimple: function ( index, direction ) {
		var $that = this,
			opts = $that.opts,
			ease = opts.ease,
			slides = $that.slides,
			viewNum = opts.viewNum,
			curIndex = $that.currentSlideIndex,
			curPagingNum = Math.floor ( curIndex / viewNum ),
			targetPagingNum = Math.floor ( index / viewNum ),
			moveWidth = $that.opts.moveWidth,
			$curSlide = slides [ curIndex ],
			$targetSlide = slides [ index ],
			dur = opts.duration;

		$that.movingFlag = true;

		var beforeEvt = $.Event ( 'beforeMove' );
		beforeEvt.beforeIndex = curIndex;
		beforeEvt.index = index;
		beforeEvt.$currentTarget = $that;
		$that.trigger ( beforeEvt );
		
		if ( curPagingNum != targetPagingNum ) {
			var targetX = -targetPagingNum * moveWidth,
				changeEvt = $.Event ( 'pageChange' );
			changeEvt.index = index;
			changeEvt.pageIndex = targetPagingNum;
			changeEvt.$currentTarget = $that;
			$that.trigger ( changeEvt );
			
			$that.stop ().animate ( { left: targetX }, dur, ease, function () {
					$that.movingFlag = false;
					var afterEvt = $.Event ( 'afterMove' );
					afterEvt.index = index;
					afterEvt.$currentTarget = $that;
					$that.trigger ( afterEvt );
				} );
		} else {
			$that.movingFlag = false;
			var afterEvt = $.Event ( 'afterMove' );
			afterEvt.index = index;
			afterEvt.$currentTarget = $that;
			$that.trigger ( afterEvt );
		}

		$that.currentSlideIndex = index;
	},
	moveToFade: function ( index, direction ) {
		var $that = this,
			opts = $that.opts,
			ease = opts.ease,
			slides = $that.slides,
			curIndex = $that.currentSlideIndex,
			$curSlide = slides [ curIndex ],
			$targetSlide = slides [ index ],
			direction = ( direction ) ? direction : index - curIndex,
			moveWidth = opts.moveWidth,
			dur = opts.duration;
		
		$that.movingFlag = true;

		var beforeEvt = $.Event ( 'beforeMove' );
		beforeEvt.index = index;
		beforeEvt.beforeIndex = curIndex;
		beforeEvt.$currentTarget = $that;
		$that.trigger ( beforeEvt );
		if ( direction ) {
			$curSlide.stop ().
				css ( { zIndex: 1 } ).
				animate ( { opacity: 0 }, dur, function () {
					$curSlide.css ( { display: 'none' } );
				} );
			$targetSlide.stop ().
				css ( { opacity: 0, zIndex: 8, display: 'block' } ).
				animate ( { opacity: 1 }, dur, function () {
					$that.movingFlag = false;
					var afterEvt = $.Event ( 'afterMove' );
					afterEvt.index = index;
					afterEvt.$currentTarget = $that;
					$that.trigger ( afterEvt );
				} );
		}

		$that.currentSlideIndex = index;
	},
	moveToFadeExtend: function ( index, direction, duration ) {
		var $that = this,
			opts = $that.opts,
			ease = opts.ease,
			slides = $that.slides,
			curIndex = $that.currentSlideIndex,
			$curSlide = slides [ curIndex ],
			$targetSlide = slides [ index ],
			direction = ( direction ) ? direction : index - curIndex,
			moveWidth = opts.moveWidth,
			dur = ( typeof duration != 'undefined' ) ? duration : opts.duration;
		
		$that.movingFlag = true;

		var beforeEvt = $.Event ( 'beforeMove' );
		beforeEvt.index = index;
		beforeEvt.beforeIndex = curIndex;
		beforeEvt.$currentTarget = $that;
		$that.trigger ( beforeEvt ); 

		if ( direction ) {
			var moveIndex = direction / Math.abs ( direction ),
				hidePos = -moveIndex * moveWidth / 10,
				showPos = moveIndex * moveWidth / 10;
			
			if ( opts.use3d && $that.transform ) {
				var transform = $that.transform,
					transition = $that.transition,
					transitionEnd = $that.transitionEnd,
					hideCssProp = {},
					showCssProp = {};
				hideCssProp [ 'opacity' ] = 0;
				hideCssProp [ 'zIndex' ] = 1;
				hideCssProp [ transform ] = 'translate3d(' + hidePos + 'px,0px,0px)';
				hideCssProp [ transition ] = 'all ' + dur + 'ms ease-out';
				
				showCssProp [ 'display' ] = 'block';
				showCssProp [ 'zIndex' ] = 8;
				showCssProp [ 'opacity' ] = 0;
				showCssProp [ transform ] = 'translate3d(' + showPos + 'px,0px,0px)';
				
				$targetSlide.css ( showCssProp );
				
				setTimeout ( function () {
					$curSlide.off ( 'transitionend' ).one ( 'transitionend', function ( e ) {
						$curSlide.css ( { display: 'none' } );
					} ).css ( hideCssProp );

					showCssProp [ 'opacity' ] = 1;
					showCssProp [ transform ] = 'translate3d(0px,0px,0px)';
					showCssProp [ transition ] = 'all ' + dur + 'ms ease-out';

					$targetSlide.off ( 'transitionend' ).one ( 'transitionend', function () {
						$that.movingFlag = false;
						var afterEvt = $.Event ( 'afterMove' );
						afterEvt.index = index;
						afterEvt.$currentTarget = $that;
						$that.trigger ( afterEvt );
					} ).css ( showCssProp );
				}, 1 );
			
			} else {
				$curSlide.stop ().
					css ( { zIndex: 1 } ).
					animate ( { left: hidePos, opacity: 0 }, dur, ease, function () {
						$curSlide.css ( { display: 'none' } );
					} );
				
				$targetSlide.stop ().
					css ( { left: showPos, opacity: 0, zIndex: 8, display: 'block' } ).
					animate ( { left: 0, opacity: 1 }, dur, ease, function () {
						$that.movingFlag = false;
						var afterEvt = $.Event ( 'afterMove' );
						afterEvt.index = index;
						afterEvt.$currentTarget = $that;
						$that.trigger ( afterEvt );
					} );
			}
		}

		$that.currentSlideIndex = index;
	},
	moveToInfinite: function ( index, direction ) {
		var $that = this,
			isMoving = $that.isMoving (),
			opts = $that.opts,
			ease = opts.ease,
			slides = $that.slides,
			curIndex = $that.currentSlideIndex,
			$curSlide = slides [ curIndex ],
			$targetSlide = slides [ index ],
			direction = ( direction ) ? direction : index - curIndex,
			moveWidth = opts.moveWidth,
			dur = opts.duration;

		if ( isMoving ) {
			return;
		}
		
		$that.movingFlag = true;

		var beforeEvt = $.Event ( 'beforeMove' );
		beforeEvt.index = index;
		beforeEvt.beforeIndex = curIndex;
		beforeEvt.$currentTarget = $that;
		$that.trigger ( beforeEvt );

		if ( direction ) {
			var moveIndex = direction / Math.abs ( direction ),
				hidePos = -moveIndex * moveWidth,
				showPos = moveIndex * moveWidth;

			if ( !$targetSlide.is ( ':visible' ) ) {
				$targetSlide.css ( { left: showPos, display: 'block' } );
			}
			$that.animate ( { left: hidePos }, dur, ease, function () {
				$curSlide.css ( { display: 'none' } );
				$targetSlide.css ( { left: 0 } );
				$that.css ( { left: 0 } );
				$that.movingFlag = false;
				var afterEvt = $.Event ( 'afterMove' );
				afterEvt.index = index;
				afterEvt.$currentTarget = $that;
				$that.trigger ( afterEvt );
			} );
		}

		$that.currentSlideIndex = index;
	},
	over: function () {},
	out: function () {},
	overToInfinite: function ( direction ) {
		if ( this.isMoving () ) {
			return;
		}
		var $that = this,
			opts = $that.opts,
			curIndex = $that.currentSlideIndex,
			slides = $that.slides,
			moveWidth = opts.moveWidth,
			showPos = direction * moveWidth,
			effectWidth = 100 * -direction,
			$effectSlide1 = slides [ curIndex ],
			$effectSlide2 = slides [ $that.getTargetIndex ( direction ) ];

		$effectSlide2.css ( { left: showPos, display: 'block' } );
		$that.stop ().animate ( { left: effectWidth }, 300 );
	},
	outToInfinite: function ( direction ) {
		if ( this.isMoving () ) {
			return;
		}
		var $that = this,
			opts = $that.opts,
			curIndex = $that.currentSlideIndex,
			slides = $that.slides,
			moveWidth = opts.moveWidth,
			hidePos = direction * moveWidth,
			$effectSlide1 = slides [ curIndex ],
			$effectSlide2 = slides [ $that.getTargetIndex ( direction ) ];

		$that.stop ().animate ( { left: 0 }, 300, function () {
			$effectSlide2.css ( { display: 'none' } );
		} );
	},
	getTargetIndex: function ( direction ) {
		var $that = this,
			total = $that.slideTotal,
			curIdx = $that.currentSlideIndex,
			targetIdx;
		if ( direction == 'next' || direction == 1 ) {
			targetIdx = curIdx + 1;
		} else {
			targetIdx = curIdx - 1;
		}
		return ( targetIdx < 0 ) ? total - 1 : targetIdx % total;
	},
	slideSelectHn: function ( e ) {
		e.preventDefault ();
		var $currentTarget = e.data.$currentTarget,
			event = $.Event ( 'itemSelect' );
		event.$currentTarget = $currentTarget;
		event.index = e.index;
		$currentTarget.trigger ( event );
	},
	prevHn: function ( e ) {
		e.preventDefault ();
		var $that = e.data.$delegateTarget;
		switch ( e.type ) {
		    case 'mouseover':
				$that.over ( -1 );
				break;
			case 'mouseout':
				$that.out ( -1 );
				break;
			case 'click':
				$that.prevSlide ();
				break;
		}
	},
	nextHn: function ( e ) {
		e.preventDefault ();
		var $that = e.data.$delegateTarget;
		switch ( e.type ) {
		    case 'mouseover':
				$that.over ( 1 );
				break;
			case 'mouseout':
				$that.out ( 1 );
				break;
			case 'click':
				$that.nextSlide ();
				break;
		}
	},
	enterLeaveHn: function ( e ) {
		var $that = e.data.$delegateTarget;
		if ( e.type == 'mouseenter' ) {
			$that.rollingStop ();
		} else {
			$that.rollingStart ();
		}
	},
	updateCountingHn: function ( e ) {
		var $that = e.data.$currentTarget;
		$that.updateCounting ( e.index );
	}
};

var CircularRollingBasicItem = function ( opts ) {
	var $that = this,
		opts = $.extend ( {}, CircularRollingBasicItem.defaults, opts );
	
	// 멤버변수 설정
	$that.opts = opts;
	$.extend ( $that, CircularRollingBasicItem.method );
	$that.timer = null;
	// 초기화
	$that.init ();
	return $that;
};
CircularRollingBasicItem.defaults = {
	index: 0,
	isPreventDefault: false,
	selectEventType: 'click'
};
CircularRollingBasicItem.method = {
	init: function () {
		var $that = this,
			opts = $that.opts,
			isPreventDefault = opts.isPreventDefault;

		if ( opts.selectEventType == 'mouseenter' ) {
			$that.on ( 'mouseover', { $currentTarget: $that }, $that.overHn );
			$that.on ( 'mouseout', { $currentTarget: $that }, $that.outHn );
		}

		if ( opts.selectEventType == 'click' ) {
			$that.on ( 'click', { $currentTarget: $that }, $that.clickHn );
		}
	},
	getIndex: function () {
		return this.opts.index;
	},
	triggerSelect: function () {
		var	$that = this,
			event = $.Event ( 'select' );
		
		event.$currentTarget = $that;
		event.index = $that.opts.index;
		$that.trigger ( event );	
	},
	clickHn: function ( e ) {
		var $currentTarget = e.data.$currentTarget,
			opts = $currentTarget.opts,
			isPreventDefault = opts.isPreventDefault;

		if ( isPreventDefault ) {
			e.preventDefault ();
		}
		$currentTarget.triggerSelect ();
	},
	/*overHn: function ( e ) {
		var $currentTarget = e.data.$currentTarget;
		$currentTarget.triggerSelect ();
	},*/
	overHn: function ( e ) {
		var $currentTarget = e.data.$currentTarget;
		if ( $currentTarget.timer ) {
			clearTimeout ( $currentTarget.timer );
			$currentTarget.timer = null;
		}
		$currentTarget.timer = setTimeout ( CJOSCommon.util.scopeBind ( $currentTarget, $currentTarget.triggerSelect ), 100 );
	},
	outHn: function ( e ) {
		var $currentTarget = e.data.$currentTarget; 
		if ( $currentTarget.timer ) {
			clearTimeout ( $currentTarget.timer );
			$currentTarget.timer = null;
		}
	},
	triggerEnter: function () {
		this.triggerSelect ( e.data.$currentTarget );
	}
}

$.fn.circularRolling = CircularRolling;
$.fn.circularRollingBasicItem = CircularRollingBasicItem;

} ) ( jQuery ); // e : Circular Rolling Component


/**
 * public jquery library
 */

/*
 * jQuery Easing Compatibility v1 - http://gsgd.co.uk/sandbox/jquery.easing.php
 *
 * Adds compatibility for applications that use the pre 1.2 easing names
 *
 * Copyright (c) 2007 George Smith
 * Licensed under the MIT License:
 *   http://www.opensource.org/licenses/mit-license.php
 */
jQuery.extend( jQuery.easing,
{
	easeIn: function (x, t, b, c, d) {
		return jQuery.easing.easeInQuad(x, t, b, c, d);
	},
	easeOut: function (x, t, b, c, d) {
		return jQuery.easing.easeOutQuad(x, t, b, c, d);
	},
	easeInOut: function (x, t, b, c, d) {
		return jQuery.easing.easeInOutQuad(x, t, b, c, d);
	},
	expoin: function(x, t, b, c, d) {
		return jQuery.easing.easeInExpo(x, t, b, c, d);
	},
	expoout: function(x, t, b, c, d) {
		return jQuery.easing.easeOutExpo(x, t, b, c, d);
	},
	expoinout: function(x, t, b, c, d) {
		return jQuery.easing.easeInOutExpo(x, t, b, c, d);
	},
	bouncein: function(x, t, b, c, d) {
		return jQuery.easing.easeInBounce(x, t, b, c, d);
	},
	bounceout: function(x, t, b, c, d) {
		return jQuery.easing.easeOutBounce(x, t, b, c, d);
	},
	bounceinout: function(x, t, b, c, d) {
		return jQuery.easing.easeInOutBounce(x, t, b, c, d);
	},
	elasin: function(x, t, b, c, d) {
		return jQuery.easing.easeInElastic(x, t, b, c, d);
	},
	elasout: function(x, t, b, c, d) {
		return jQuery.easing.easeOutElastic(x, t, b, c, d);
	},
	elasinout: function(x, t, b, c, d) {
		return jQuery.easing.easeInOutElastic(x, t, b, c, d);
	},
	backin: function(x, t, b, c, d) {
		return jQuery.easing.easeInBack(x, t, b, c, d);
	},
	backout: function(x, t, b, c, d) {
		return jQuery.easing.easeOutBack(x, t, b, c, d);
	},
	backinout: function(x, t, b, c, d) {
		return jQuery.easing.easeInOutBack(x, t, b, c, d);
	}
});



