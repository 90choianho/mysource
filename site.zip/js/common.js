// Core object start
if (typeof window != "undefined") {
	if (typeof window.hosting == "undefined") {
		window.toptoon = {};
	}
} else {
	if (!gabia) {
		toptoon = {};
	}
}

/*
//모바일 판단 클래스
toptoon.moble_checker = function () {
	this.mobile_domain = "";
	this.mobile_index = "/mobile/index.php";

	this.checkClient = function() {
		if ( this.isMobileDomain() || this.isMobile() ) {
			var url = "http://" + this.mobile_domain + this.mobile_index;
			location.href = url;
		}
	}

	this.isMobileDomain = function () {
		if (this.mobile_domain.toLowerCase() == location.host.toLowerCase()) {
			return true;
		} else {
			return false;
		}
	}

	this.isMobile = function(){
		if( navigator.userAgent.match(/Android|BlackBerry|Opera Mini|IEMobile|iPhone|iPad|iPod/i) ) {
			return true;
		}
		else{
			return false;
		}
	}
}

var param = document.location.search;
var mobile_checker = new toptoon.moble_checker();//모바일사이트 도메인
mobile_checker.mobile_domain = "mobile.toptoon.com";//모바일사이트 메인페이지의 절대경로
mobile_checker.mobile_index = "/"+param;//모바일주소(m.domain.com) 이거나 모바일기기 접속일 경우 페이지 이동, 선택사항 모바일접속시m. 없이 도메인만적어도 모바일로 접속
mobile_checker.checkClient();
*/

$(document).ready(function(){
	// ajax 통신 중 로딩 바 
	// 현재 페이지에서 ajax 통신이 시작될 경우 실행될 이벤트
/*
	$('body').append("<div id='hiddenDivLoading' style='display:none; position:fixed;'><iframe id='iframeLoading' frameborder='0' height='134px' style='z-index:-1; position:absolute; visibility:hidden'></iframe><div id='load'><img src='/assets/img/admin/ajax-loader.gif' /></div></div>");
	$(document).ajaxStart(function() {
		// 화면의 중앙에 위치하도록 top, left 조정 (화면에 따라 조정 필요)
		$("#hiddenDivLoading").show().css({
//	        top: $(document).scrollTop() + ($(window).height() / 2) - ($("#hiddenDivLoading").height() / 2) + 'px',
	        top: ($(window).height() / 2) - ($("#hiddenDivLoading").height() / 2) + 'px',
//	        left: $(document).scrollLeft() + ($(window).width() / 2) - ($("#hiddenDivLoading").width() / 2) + 'px'
	        left: ($(window).width() / 2) - ($("#hiddenDivLoading").width() / 2) + 'px'
	    });
	// ajax 통신이 종료되었을 때 실행될 이벤트
	}).ajaxStop(function() {
		// 로딩 바 hide 처리
		$("#hiddenDivLoading").hide();
	});
*/
	
	//추가(json post로 전송)
	$.extend({
		postJSON: function(url, data, callback){
			$.post(url, data, callback, "json");
		}
	});
	
	//my info
	$('#smenu_myinfo').hover(function(){		
		$('#my_info:not(:animated)').slideDown('fast');
	});
	
	$('#my_info').hover(function(){},function(){
		$('#my_info').slideUp('fast');
	});
	
	/* 코믹 리스트 */
	var comic_list_check = false;//전체 코믹 리스트
	$('#comic_search').focus(function () {
		if (!comic_list_check) {
			/* 코믹 리스트 */
			$.ajax({
				type	: 'GET',
				url		: '/assets/json/mobile/comic_list.json',
				cache	: true,
				success	: function(data) {
					comic_list = data;
				}
			});	
			comic_list_check = true;
		}
	});
	
	//만화 검색
	var tmp_comic_search_str = '';
	/* 파이어폭스 버그 추가 */
	var keySearch = new beta.fix('comic_search');
	$('#comic_search').keyup(function(e){
		if(e.keyCode>=37 && e.keyCode<=40){
			return false;
		}else if(e.keyCode==13){
			/* 오픈예정 */
			if ($('.autobox ul li.active').attr('data-induce-status') == '3') {
				comic_alert_view($('.autobox ul li.active'));
			} 
			else if($('.autobox ul li.active').length){
				if($('.autobox ul li.active').attr('data-content-type')==2 || $('.autobox ul li.active').attr('data-content-type')==5){//소설
			
					if($('.autobox ul li.active').attr('data-content-type')==2){	
						var dom = (document.location.href.match(/http[s]*:\/\/([a-zA-Z0-9\-\.]*)/)[0]);
						if(dom.indexOf('book.')==-1){
							dom = dom.replace('toptoon.', 'book.toptoon.');
						}
						location.href=dom+"/novel/ep_list/"+$('.autobox ul li.active').attr('data-comic-id');
					}else{
						
						var dom = (document.location.href.match(/http[s]*:\/\/([a-zA-Z0-9\-\.]*)/)[0].replace('book.', ''));				
						location.href=dom+"/novel/ep_list/"+$('.autobox ul li.active').attr('data-comic-id');						
					}	
				}else{
					var dom = (document.location.href.match(/http[s]*:\/\/([a-zA-Z0-9\-\.]*)/)[0].replace('book.', ''));
					location.href=dom+"/comic/ep_list/"+$('.autobox ul li.active').attr('data-comic-id');
				}
			}
		}
		$('#search_comic').empty();
		$('#search_photo').empty();
		$('#search_unlimit').empty();
		$('#search_novle').empty();
		var val = $(this).val();
		tmp_comic_search_str = val;
		if(val){
			$('#comic_search_back').val('');
			var comic_athor = get_json_array(comic_list, 'comic_name', val);
			if(comic_athor.length){
				set_comic_search('#search_result_comic', comic_athor, 'comic', val);
			}
		}else{
			var dom = (document.location.href.match(/http[s]*:\/\/([a-zA-Z0-9\-\.]*)/)[0]);
			if(dom.indexOf('book.')==-1){
				$('#comic_search_back').val('만화/작가 찾기');
			}else{
				$('#comic_search_back').val('소설/작가 찾기');
			}
		}
	});
	
	//만화 검색 결과 이동
	$('#comic_search').keydown(function(e){
		var keycode = e.keyCode;
		var comic_length 		= $('.autobox').find('li').length;
		var comic_active_length = $('.autobox').find('li.active').length;
		var comic_eq			= comic_length-1;
		
		/* 올림 */
		if (keycode == '38') {
			var active_li_eq;
			/* 선택 active 삭제 및 active index */
			$('.autobox').find('li').each(function (key, value) {
				if ($(this).hasClass('active')) {
					if (key == 0) {
						active_li_eq = comic_eq;
					} else {
						active_li_eq = key-1;
					}
				}
				$(this).removeClass('active');
			});
			
			var comic_name = '';
			$('.autobox').find('li').each(function (key, value) {
				
				/* 마지막 */
				if (comic_active_length == 0 && key == comic_eq) {
					$(this).addClass('active');
					comic_name = $(this).attr('data-comic-name');
				} else {
					if (key == active_li_eq) {
						$(this).addClass('active');
						comic_name = $(this).attr('data-comic-name');
					}
				}
				
			});
			
			$('#comic_search').val(comic_name);
		} 
		/* 내림 */
		else if (keycode == '40') {
			var active_li_eq;
			/* 선택 active 삭제 및 active index */
			$('.autobox').find('li').each(function (key, value) {
				if ($(this).hasClass('active')) {
					if (comic_eq == key) {
						active_li_eq = 0;
					} else {
						active_li_eq = key+1;
					}
				}
				$(this).removeClass('active');
			});
			
			var comic_name = '';
			$('.autobox').find('li').each(function (key, value) {
				
				/* 첫번째 */
				if (comic_active_length == 0 && key == 0) {
					$(this).addClass('active');
					comic_name = $(this).attr('data-comic-name');
				} else {
					if (key == active_li_eq) {
						$(this).addClass('active');
						comic_name = $(this).attr('data-comic-name');
					}
				}
				
			});
			
			$('#comic_search').val(comic_name);
		}
	});
	
	//만화 검색 결과 영역 보이기
	$('#comic_search').focus(function(e){
		$('.autobox').show();
		$('#comic_search_back').val('');
		$('#comic_search_back').val($(".autobox ul li[data-type='comic']").first().attr('data-comic-name'));
	});
	
	//만화 검색 삭제
	function remove_search_result()
	{
		$('.autobox ul li.active').removeClass('active');
		$('#comic_search').val(tmp_comic_search_str);
		$('#comic_search_back').val('');
		if($.trim($('#comic_search').val()).length==0) {
			var dom = (document.location.href.match(/http[s]*:\/\/([a-zA-Z0-9\-\.]*)/)[0]);
			if(dom.indexOf('book.')==-1){
				$('#comic_search_back').val('만화/작가 찾기');
			}else{
				$('#comic_search_back').val('소설/작가 찾기');
			}
		}
		setTimeout(function(){$('.autobox').hide()},200);
	}

	$(document).on('mouseenter','.autobox',function(){
		$('#comic_search').unbind('blur');
	});

	$(document).on('mouseleave','.autobox',function(){
		$('#comic_search').bind('blur',function(){
			remove_search_result();
		});
	});

	$(document).on('click',function(event){
		if ($(event.target).closest('.autobox').length <= 0 && $(event.target).closest('.search').length <= 0)
			remove_search_result();
	});	

	$('#comic_search').blur(function(e){
		remove_search_result();
	});

	$('.toon_area').click(function(){
		var comic_id = $(this).attr('data-comic-id');
		// var comic_weekly = $(this).attr('data-comic-weekly')?$(this).attr('data-comic-weekly'):'';
		// location.href='/comic/ep_list/'+comic_id+'/'+comic_weekly;
		location.href='/comic/ep_list/'+comic_id;
		return false;
	});
	
	$('.novel_area').click(function(){
		var comic_id = $(this).attr('data-comic-id');
		location.href='/novel/ep_list/'+comic_id;
		return false;
	});
	
	//공지사항 rss출력
	set_feed('#rss_notice', 'http://blog.rss.naver.com/toptoonkr', 3);
});

//연재 예정 만화 얼럿
function comic_alert_view(obj) {
    var comic_idx = $(obj).attr('data-comic-idx');
    var list_division = $(obj).attr('data-division');
    $("#alert_layer").load('/alert/comic_alert/'+comic_idx+'/'+list_division, function(){
        ShowAlert("#alert_layer");
        /* 유도 알림 리스트 찜하기 */
        if (list_division == 'list_favorite') {
        	$('#favorite_close').css('top', '10px');
        	$('#favorite_close').css('right', '3px');
        }
    });
}

/* 소장 */
var checkPurchase_list_view = function(obj)	{

	var comic_id = obj.attr('data-comic-id');
	var episode_id = obj.attr('data-episode-id');

	var json_parm = null;
	var json_url = "/comic/purchase_check/"+comic_id+"/"+episode_id;

	$.postJSON(json_url, json_parm, function(data, status)	{
		if(data.result)	{
			location.href="/comic/ep_purchase/"+comic_id+"/"+episode_id;
			return false;
		}
		else if(data.alert_url)
			$("#alert_layer").load(data.alert_url, function(){
				ShowAlert("#alert_layer");
				/*var layer_center = ($(window).height() - $('#alert_layer').outerHeight()) / 2 + $(window).scrollTop();
	            $("#alert_layer").css('top', layer_center+'px');*/
			});
		else
			alert(data.message);
	});
	return false;
}
/* 소장 */

//rss 긁어와 뿌리기
function set_feed(obj, url, count) {
	var idd=$(obj).attr('id');

	$.feedToJson({
		feed:url,
		success: function(data){
			$('#'+idd).empty();
			$.each(data.item,function(i,entry){
				var rsstitle = entry.title;
				var tmp = entry.pubDate;
				var dt = new Date(tmp);
				var yyyy = dt.getFullYear();
				var mm = dt.getMonth()+1;
				var dd = dt.getDate();
				var top = i==0?'0px;':'30px;';
				$('#'+idd).append('<li style="top:'+top+'"><a href="' + entry.link + '" target="_blank">'+(yyyy+'.'+mm+'.'+dd)+' '+rsstitle.substring(0, 40)+'</a></li>');
			});
			if(data.item.length>1) setInterval(function(){show_start($('#'+idd))}, 5000);
		}
	});

	/* var idd=$(obj).attr('id');
	$.ajax({
		url:'http://ajax.googleapis.com/ajax/services/feed/load?v=1.0&num='+count+'&output=json&q='+encodeURIComponent(url)+'&callback=?',dataType:'json',success:function(data) {
			$('#'+idd).empty();
			var rss_length = data.responseData.feed.entries.length;
			var i = 0;
			$.each(data.responseData.feed.entries,function(i,entry) {
				var rsstitle = entry.title;
				var tmp = entry.publishedDate;
				var dt = new Date(tmp);
				var yyyy = dt.getFullYear();
				var mm = dt.getMonth()+1;
				var dd = dt.getDate();
				var top = i==0?'0px;':'30px;';
				$('#'+idd).append('<li style="top:'+top+'"><a href="' + entry.link + '" target="_blank">'+(yyyy+'.'+mm+'.'+dd)+' '+rsstitle.substring(0, 40)+'</a></li>');
				i = i+1;
			});
			if(rss_length>1) setInterval(function(){show_start($('#'+idd))}, 5000);
		}
	}); */
}

//rss annimation
function show_start(obj) {
	var t = $(obj).children('li');
    mt = t.first();
    mt.animate({top:30}).next().animate(
    	{top:0},function(){
        	$(obj).append(mt);
    	}
    );
}

//jquery 배열 검색
function get_json_array(obj, key, val) {
    var objects = [];
    var val = val.toUpperCase();
    $.each(obj.search_list, function (key, value) {
    	// 2016-10-06 작가명 null 일때 toUpperCase 스크립트오류
    	var author_flag = -1;
    	if(value.new_author_list != null) {
    		author_flag = value.new_author_list.toUpperCase().indexOf(val);
    	}
    	if (value.comic_name.toUpperCase().indexOf(val) >= 0 || author_flag >= 0) {
    		objects.push(value);
    	}
//    	if (value.comic_name.toUpperCase().indexOf(val) >= 0 || value.comic_author.toUpperCase().indexOf(val) >= 0) {
//    		objects.push(value);
//    	}
    });
    return objects;
}

//만화 검색 리스트 생성
function set_comic_search(obj, arr, type, search_keyword){

	/* 검색어 매칭 */
	var i = 0; var y = 0; var k = 0; var z = 0;
	var user_device_bit		= parseInt($('#search_user_device_bit').val());
	var user_idx 			= parseInt($('#search_user_idx').val());
	var webtoon_html = ""; var photo_html = ""; var unlimit_html = ""; var novel_html = "";

	$(arr).each(function(index, value){
		
		if (value.view_status&user_device_bit>0) {
			
			/* 만화 */
			if (value.content_type == 1) {
				/* 일반연재, 출판만화 */
				if (value.comic_type&9 || value.comic_type&16 || value.comic_type&32) {	
					if (i==0) {
						webtoon_html += "<h1 class='ser_tit'><a href='javascript:;'>만화</a></h1>";
					}
					webtoon_html += "<li data-comic-idx='"+value.idx+"' data-induce-status='"+value.induce_status+"' data-content-type='"+value.content_type+"' data-comic-id='"+value.comic_id+"' data-comic-name='"+value.comic_name+"' data-type='"+type+"'><div class='img' style='background-image: url(/img/co_thumb1/"+value.idx+"); background-repeat: no-repeat; background-position: 50%; background-size:cover;'></div><div class='text'><span>"+value.comic_name+"</span>"+value.new_author_list+"</div></li>";
					i++;
				}
				/* 포토툰 */
				else if (value.comic_type&256) {
					if (y==0) {
						photo_html += "<h1 class='ser_tit'><a href='javascript:;'>포토툰</a></h1>";
					}
					photo_html += "<li data-comic-idx='"+value.idx+"' data-induce-status='"+value.induce_status+"' data-content-type='"+value.content_type+"' data-comic-id='"+value.comic_id+"' data-comic-name='"+value.comic_name+"' data-type='"+type+"'><div class='img' style='background-image: url(/img/co_thumb1/"+value.idx+"); background-repeat: no-repeat; background-position: 50%; background-size:cover;'></div><div class='text'><span>"+value.comic_name+"</span>"+value.new_author_list+"</div></li>";
					y++;
				}
				
			}
			/* 정액관 */
			else if (value.content_type == 4) {
				if (k==0) {
					unlimit_html += "<h1 class='ser_tit'><a href='javascript:;'>정액관</a></h1>";
				}
				unlimit_html += "<li data-comic-idx='"+value.idx+"' data-induce-status='"+value.induce_status+"' data-content-type='"+value.content_type+"' data-comic-id='"+value.comic_id+"' data-comic-name='"+value.comic_name+"' data-type='"+type+"'><div class='img' style='background-image: url(/img/co_thumb1/"+value.idx+"); background-repeat: no-repeat; background-position: 50%; background-size:cover;'></div><div class='text'><span>"+value.comic_name+"</span>"+value.new_author_list+"</div></li>";
				k++;
			}
			/* 소설 */
			else if (value.content_type == 2) {
				if (z==0) {
					novel_html += "<h1 class='ser_tit'><a href='javascript:;'>소설</a></h1>";
				}
				novel_html += "<li data-comic-idx='"+value.idx+"' data-induce-status='"+value.induce_status+"' data-content-type='"+value.content_type+"' data-comic-id='"+value.comic_id+"' data-comic-name='"+value.comic_name+"' data-type='"+type+"'><div class='img' style='background-image: url(/img/co_thumb1/"+value.idx+"); background-repeat: no-repeat; background-position: 50%; background-size:cover;'></div><div class='text'><span>"+value.comic_name+"</span>"+value.new_author_list+"</div></li>";
				z++;
			}
		}
	});
	
	/* 각 만화,소설 html */
	var log_comic_search = false;	// 검색결과 존재 유무
	if (webtoon_html != '') {
		$('#search_comic').html(webtoon_html).show();
		log_comic_search = true;
	}
	if (photo_html != '') {
		$('#search_photo').html(photo_html).show();
		log_comic_search = true;
	}
	if (unlimit_html != '') {
		$('#search_unlimit').html(unlimit_html).show();
		log_comic_search = true;
	}
	if (novel_html != '') {
		$('#search_novle').html(novel_html).show();
		log_comic_search = true;
	}
	
	/* 검색 결과 존재시 검색어 insert */
	if (log_comic_search) {

		/*
		$.ajax({
			type	: 'GET',
			url		: '/log/set_log_search_keyword',
			data	: { search_keyword:search_keyword, device_type:1 },
			cache	: false,
            async	: false,
			success	: function(data) {

			}
		});
		*/
		
		$.ajax({
			type	: 'GET',
			url		: 'http://ad.toptoon.com/log/keyword.php',
			data	: { search_keyword:search_keyword, device_type:1 },
			cache	: false,
            async	: false,
			success	: function(data) {

			}
		});
	}
	
	//검색 결과 마우스 오버시
	$('.autobox ul li').mouseover(function(){
			$('.autobox ul li.active').removeClass('active');
			$(this).addClass('active');
	});
	
	//검색 결과 클릭시 이동
	$('.autobox ul li').click(function(){
		/* 오픈예정 */
		if ($(this).attr('data-induce-status') == 3) {
			comic_alert_view($(this));
		}
		else {
			if($(this).attr('data-content-type')==2 || $(this).attr('data-content-type')==5){//소설
				
				if($(this).attr('data-content-type')==2){
					var dom = (document.location.href.match(/http[s]*:\/\/([a-zA-Z0-9\-\.]*)/)[0]);
					if(dom.indexOf('book.')==-1){
						dom = dom.replace('toptoon.', 'book.toptoon.');
					}
					location.href="/novel/ep_list/"+$(this).attr('data-comic-id');
				}else{
					
					var dom = (document.location.href.match(/http[s]*:\/\/([a-zA-Z0-9\-\.]*)/)[0].replace('book.', ''));
					//alert(dom+"/novel/ep_list/"+$(this).attr('data-comic-id'));
					location.href="/novel/ep_list/"+$(this).attr('data-comic-id');
				}
				
				
				
			}else{
				var dom = (document.location.href.match(/http[s]*:\/\/([a-zA-Z0-9\-\.]*)/)[0].replace('book.', ''));
				location.href=dom+"/comic/ep_list/"+$(this).attr('data-comic-id');
			}
		}
	});
	return false;
}

//paging tag 생성
var call_paging_time = '';

function set_paging(display_cnt, total_cnt_obj, page_obj, total_cnt, onChangeFnc){	
	if($(page_obj).val() > Math.ceil(total_cnt/$(display_cnt).val()) && $('.jPaginate a.paging-item').length){
		if(call_paging_time+1000 < Date('milliseconds')){//없는 페이지 계속 호출되는 무한루프 방지-정상적인 카운트의 페이징은 이 처리 하지 않아도 무한루프 돌지 않음
			call_paging_time = Date('milliseconds');
			$('.jPaginate a.paging-item').last().prev().click();
		}
	}else{
		$(total_cnt_obj).val(total_cnt);
		$('#pagination').paging({
			current:$(page_obj).val(),
			max:Math.ceil(total_cnt/$(display_cnt).val()),
			onclick:onChangeFnc
		});
	}
	return false;
}
//input 숫자만 입력가능
function only_number(event, add_grp, add_keycode, key_alert){
	if(key_alert) alert(event.keyCode);
	if(
		(event.keyCode>=48 && event.keyCode<=57)//0~9
		|| (event.keyCode>=96 && event.keyCode<=105)//키패드 숫자
		|| (event.keyCode>=32 && event.keyCode<=40)//Spacebar, PageUP, PageDW, ESC, HOME, 방향키
		|| (event.keyCode>=112 && event.keyCode<=127)//F1~F12
		|| event.keyCode==8//Backspace
		|| event.keyCode==9//Tab
		|| event.keyCode==13//Enter
		|| event.keyCode==16//Shift
		|| event.keyCode==20//Caps Lock
		|| event.keyCode==27//ESC
		|| event.keyCode==46//Del
	){
		return true;
	}else{
		if(add_grp){
			if(add_grp=='eng'){
				if(event.keyCode>=65 && event.keyCode<=90){
					return true;
				}
			}
		}
		if(add_keycode){
			if(event.keyCode==add_keycode){
				return true;
			}
		}
		event.returnValue = false;
	}
}

//full screen
function cancelFullScreen(docElement) {
    var requestMethod = docElement.cancelFullScreen|| docElement.webkitCancelFullScreen || docElement.mozCancelFullScreen || docElement.msCancelFullScreen || docElement.exitFullscreen;
    if (requestMethod) { // cancel full screen.
        requestMethod.call(docElement);
    }
}

function requestFullScreen(docElement) {
    // Supports most browsers and their versions.
    var requestMethod = docElement.requestFullScreen || docElement.webkitRequestFullScreen || docElement.mozRequestFullScreen || docElement.msRequestFullScreen;

    if (requestMethod) { // Native full screen.
        requestMethod.call(docElement);
    }
    return false;
}

function toggleFull() {
    var elem = document.documentElement; // Make the body go full screen.
    var isInFullScreen = (document.fullScreenElement && document.fullScreenElement !== null) ||  (document.mozFullScreen || document.webkitIsFullScreen);

    if (isInFullScreen) {
        cancelFullScreen(document);
    } else {
        requestFullScreen(elem);
    }
    return false;
}
//full screen End

function str_cut(str, len) {
	var s = 0;
	for (var i=0; i<str.length; i++) {
		s += (str.charCodeAt(i) > 128) ? 2 : 1;
		if (s > len) return str.substring(0,i) + "...";
	} 
	return str;
} 

function getMakeDate(yyyy, mm, dd, sep){
	var today = new Date();
	var year = today.getFullYear();
	var month = today.getMonth();
	var day = today.getDate();
	
	var resultDate = new Date(yyyy+year, month+mm, day+dd);
	
	
	year = resultDate.getFullYear();
	month = resultDate.getMonth() + 1;
	day = resultDate.getDate();
	
	if (month < 10)
		month = "0" + month;
	if (day < 10)
		day = "0" + day;
		
	return year + sep + month + sep + day;
 }

function getCookie(cookieName){
    var cookieValue=null;
    if(document.cookie){
        var array=document.cookie.split((escape(cookieName)+'=')); 
        if(array.length >= 2){
            var arraySub=array[1].split(';');
            cookieValue=unescape(arraySub[0]);
        }
    }
    return cookieValue;
}

function setCookie(name, value, expiredays){ 
    var todayDate = new Date(); 
    if(expiredays == 'today') { //종료일 'today' 로 되어있을 경우 오늘 자정까지..
        todayDate.setDate(todayDate.getDate());
        todayDate.setHours(23);
        todayDate.setMinutes(59);
        todayDate.setSeconds(59); 
    }
    else if(expiredays == 'hour') {
    	var expirehours = 1;
    	todayDate.setDate(todayDate.getDate());
    	todayDate.setHours(todayDate.getHours()+expirehours);
    	todayDate.setMinutes(todayDate.getMinutes());
        todayDate.setSeconds(todayDate.getSeconds());
    }
    else if(expiredays == '3hour') {
    	var expirehours = 3;
    	todayDate.setDate(todayDate.getDate());
    	todayDate.setHours(todayDate.getHours()+expirehours);
    	todayDate.setMinutes(todayDate.getMinutes());
        todayDate.setSeconds(todayDate.getSeconds());
    }
    else {
        todayDate.setDate(todayDate.getDate() + expiredays); 
    }
    document.cookie = name + "=" + escape(value) + "; domain=.toptoon.com; path=/; expires=" + todayDate.toGMTString() + ";" 
} 

//만화보기 버튼 액션	
function episode_view(obj){
	
	if($(obj).attr('onclick')){return false;}//onclick 이벤트 있을경우 아래 실행 안

	var comic_id = $(obj).attr('data-comic-id');
	var episode_id = $(obj).attr('data-episode-id');
	var silver_limit = $(obj).attr('data-limit-sliver');
	var user_silver_limit = $(obj).attr('data-user-sliver');
	var ep_content_type = $(obj).attr('data-content-type');
	var comic_alert_chk = $(obj).attr('alert_induce');
	var comic_idx = $(obj).attr('data-comic-idx');
	var act = $(obj).attr('data-act');
	
//	if(comic_alert_chk == 'Y'){
//		$("#alert_layer2").load('/alert/comic_alert/'+comic_idx, function(response, status) 
//		{
//			ShowAlert_alert("#alert_layer2");
//			if(status=="success"){
//				//alert("success");				
//				//alert(status);
//			}
//			//alert(respose);
//			//ShowAlert_alert("#alert_layer");
//		});
//	}
	
	//무제한쿠폰 사용자 제한
	if(ep_content_type == 4 || ep_content_type == 5){
		if(silver_limit==1 && user_silver_limit==1){
			$("#alert_layer").load('/alert/silver_limit_check', function(){
				ShowAlert("#alert_layer");
			});
			return false;			
		}
	}
	
	var json_parm = null;
	var json_url = "/comic/location_check/"+comic_id+"/"+episode_id+"/"+act;
	$.postJSON(json_url, json_parm, function(data, status) {
		if(data.result){
			view_flag = false;
			
			//성공
			$('#last_visited').val(comic_id+','+episode_id);
			$('#visited').val($('#visited').val()+'|'+comic_id+','+episode_id);
			if(act){
				location.href="/comic/ep_view/"+comic_id+"/"+episode_id+"/"+act;
			}else{
				location.href="/comic/ep_view/"+comic_id+"/"+episode_id;
			}
			return false;
		}
		else if(data.alert_url)
		{
			//alert layer
			$("#alert_layer").load(data.alert_url, function(){
				ShowAlert("#alert_layer");
			});
		}
		else if(data.alert_url2)//모바일 때문에 alert_url2 값 받기위해 추가
		{
			
			//alert layer
			$("#alert_layer").load(data.alert_url2, function(){
				ShowAlert("#alert_layer");				
			});
		}else
		{
			//실패
			alert(data.message);
		}
	});
	return false;
}

//소설보기 버튼 액션	
function episode_view_novel(obj){
	if($(obj).attr('onclick')){return false;}//onclick 이벤트 있을경우 아래 실행 안

	var comic_id = $(obj).attr('data-comic-id');
	var episode_id = $(obj).attr('data-episode-id');
			
	var json_parm = null;
	var json_url = "/novel/location_check/"+comic_id+"/"+episode_id;
	$.postJSON(json_url, json_parm, function(data, status) {
		if(data.result){//성공
			$('#last_visited').val(comic_id+','+episode_id);
			$('#visited').val($('#visited').val()+'|'+comic_id+','+episode_id);
			location.href="/novel/ep_view/"+comic_id+"/"+episode_id;
			return false;
		}else if(data.alert_url){//alert layer
			$("#alert_layer").load(data.alert_url, function(){
				ShowAlert("#alert_layer");
			});
		}else{//실패
			alert(data.message);
		}
	});
	return false;
}

/*팝업 레이어*/
function HideAlert(layer) {
	var Layer_obj = $(layer);

	Layer_obj.css('display','none');
	$('#modal_bg').css('display','none');
	$('#modal_bg').unbind('click');
	$(window).unbind('resize');
	$('html').css('overflow', 'scroll');
}

function ShowBackground_nonclick(layer) {
//	$('#modal_bg').width($(document).width());
//	$('#modal_bg').height($(document).height());
	$('#modal_bg').fadeIn();

	$('#modal_bg').unbind('click');
//	$('#modal_bg').bind('click', function(){
//		HideAlert(layer);
//	});
}

function ShowBackground(layer) {
//	$('#modal_bg').width($(document).width());
//	$('#modal_bg').height($(document).height());
	$('#modal_bg').fadeIn();

	$('#modal_bg').unbind('click');
	$('#modal_bg').bind('click', function(){
		HideAlert(layer);
		//포인트파크 알림 레이어창 쿠키 설정용 (160714) - 레이어 미사용시 삭제 요망
		setCookie('pointpark_step', '0', 1);
	    setCookie('pointpark_alert_flag', '0', 1);
	});
}

function MaskModal(layer, status) {

	if(status){
		modal_resize = false;
		$(window).off("resize.modal");
		layer.remove();
		$('#modal_bg').hide();
	}else{
		$('#modal_bg').fadeIn();

		$('#modal_bg').unbind('click');
		$('#modal_bg').bind('click', function(){
			modal_resize = false;
			$(window).off("resize.modal");
			layer.remove();
			$('#modal_bg').hide();
		});
		modal_position(layer);
	}
}

function ShowAlert(layer) {
	ShowBackground(layer);

	var Layer_obj = $(layer);
	var LayerWidth = Layer_obj.width();
	var LayerHeight = Layer_obj.height();
	
	var left = ($(window).width()-LayerWidth)/2;
	var top = ($(window).height()-LayerHeight)/2;

	Layer_obj.css({'left':left,'top':top});
	Layer_obj.css('display','block');

	//하단 스크롤 안되게..
	$('html').css('overflow', 'hidden');

	//리사이즈시 action
	$(window).unbind('resize');
	$(window).bind('resize', function(){
		var Layer_obj = $(layer);
		var LayerWidth = Layer_obj.width();
		var LayerHeight = Layer_obj.height();
	
		var left = ($(window).width()-LayerWidth)/2;
		var top = ($(window).height()-LayerHeight)/2;

		Layer_obj.css({'left':left,'top':top});
	});
	//debugger;
	return false;
}

function ShowAlert_nonbackground(layer) {
	ShowBackground_nonclick(layer);

	var Layer_obj = $(layer);
	var LayerWidth = Layer_obj.width();
	var LayerHeight = Layer_obj.height();
	
	var left = ($(window).width()-LayerWidth)/2;
	var top = ($(window).height()-LayerHeight)/2;

	Layer_obj.css({'left':left,'top':top});
	Layer_obj.css('display','block');

	//하단 스크롤 안되게..
	$('html').css('overflow', 'hidden');

	//리사이즈시 action
	$(window).unbind('resize');
	$(window).bind('resize', function(){
		var Layer_obj = $(layer);
		var LayerWidth = Layer_obj.width();
		var LayerHeight = Layer_obj.height();
	
		var left = ($(window).width()-LayerWidth)/2;
		var top = ($(window).height()-LayerHeight)/2;

		Layer_obj.css({'left':left,'top':top});
	});
	//debugger;
	return false;
}

function ShowAlert_alert(layer) {
	ShowBackground(layer);
	//debugger;
	var Layer_obj = $(layer);
	var LayerWidth = Layer_obj.width();
	var LayerHeight = Layer_obj.height();

	var left = ($(window).width()-LayerWidth)/2;
	var top = ($(window).height()-LayerHeight)/2;

// 	Layer_obj.css({'left':left,'top':-LayerHeight});

// 	Layer_obj.css('display','block');
/*
	Layer_obj.animate({
		top: '+='+(top+LayerHeight)+'px',
	}, 500,"easeInOutQuad", function() {
		Layer_obj.css('display','block');
	});	
*/
	Layer_obj.css({'left':left,'top':top});
	Layer_obj.css('display','block');

	//하단 스크롤 안되게..
	$('html').css('overflow', 'hidden');

	//리사이즈시 action
	$(window).unbind('resize');
	$(window).bind('resize', function(){
		var Layer_obj = $(layer);
		var LayerWidth = Layer_obj.width();
		var LayerHeight = Layer_obj.height();
	
		var left = ($(window).width()-LayerWidth)/2;
		var top = ($(window).height()-LayerHeight)/2;

		Layer_obj.css({'left':left,'top':top});
	});
	
	//return Layer_obj;
}

function ShowPopupAlert(layer) {
	ShowBackground(layer);

	var Layer_obj = $(layer);
	Layer_obj.show();

	//하단 스크롤 안되게..
	$('html').css('overflow', 'hidden');
	return false;
}
var modal_resize = false;
function modal_position(modal){	
	modal.css({'position':'fixed','left':(($(window).width() - modal.width()) /2) + 'px','top':(($(window).innerHeight() - modal.height()) /2) + 'px','z-index':'1100'});
	if(modal_resize == false){
		$(window).on('resize.modal',(function(){modal_position(modal)}));
		modal_resize = true;
	}
}

	
function change_ad_banner(area_obj, allow_obj, allow){
	var act_obj = $(area_obj).find('li.active');		
	act_obj.removeClass('active');

	if(allow=='prev'){
		if(act_obj.prev().length){
			act_obj.prev().addClass('active');
		}else{
			$(area_obj).find('li').last().addClass('active');
			
		}
		$(area_obj).find('li.active').fadeIn();
		$(area_obj).find('li').not('.active').fadeOut();
	}else{
		if(act_obj.next().length){
			act_obj.next().addClass('active');
		}else{
			$(area_obj).find('li').first().addClass('active');
		}
		$(area_obj).find('li.active').fadeIn();
		$(area_obj).find('li').not('.active').fadeOut();
	}
	return false;
}
	
function slide_ad_banner(area_obj, allow_obj, allow){
	$(allow_obj).unbind('click');//클릭 못하게..

	var act_obj = $(area_obj).find('li.active');
	if(allow=='prev'){
		if(act_obj.prev().length){
			act_obj.prev().css('left', -act_obj.prev().width());
			act_obj.removeClass('active');
			act_obj.prev().addClass('active');
			act_obj.prev().show();
		}else{
			$(area_obj).find('li').last().css('left', -$(area_obj).find('li').last().width());
			$(area_obj).find('li').removeClass('active');
			$(area_obj).find('li').last().addClass('active');
			$(area_obj).find('li').last().show();
			
		}
		$(area_obj).find('li.active').animate({left: 0}, function(){
			$(area_obj).find('li').not('.active').hide();
			
			$(allow_obj).click(function(){
				slide_ad_banner(area_obj, allow_obj, 'next');
				return false;
			});
		});
	}else{
		if(act_obj.next().length){
			act_obj.next().css('left', act_obj.next().width());
			act_obj.removeClass('active');
			act_obj.next().addClass('active');
			act_obj.next().show();
		}else{
			$(area_obj).find('li').first().css('left', $(area_obj).find('li').last().width());
			$(area_obj).find('li').removeClass('active');
			$(area_obj).find('li').first().addClass('active');
			$(area_obj).find('li').first().show();
		}
		$(area_obj).find('li.active').animate({left: 0}, function(){
			$(area_obj).find('li').not('.active').hide();
			
			$(allow_obj).click(function(){
				slide_ad_banner(area_obj, allow_obj, 'prev');
				return false;
			});
		});
	}
	return false;
}

function slide_bnr(parent,pagination,count)
{
	this.curr_pos = 0;
	this.interval = 5000;
	var _this = this;
	var el = $('.'+parent);

	this.next = function()
	{
		if(_this.curr_pos + 1 < count)
			_this.curr_pos++;
		else
			_this.curr_pos = 0;
		_this.index(_this.curr_pos);
	}

	this.index = function(idx)
	{
		var el = $('.'+parent);
		var pn = $('.'+pagination);

		_this.curr_pos = idx;

		for(var i=0;i<count;i++)
		{
			el.children().eq(i).removeClass('active');
			pn.children().eq(i).removeClass('active');
			el.children().eq(i).css('display','none');
		}
		el.children().eq(idx).fadeIn();
		pn.children().eq(idx).addClass('active');
	}

	this.start_timer = function()
	{
		_this.timer = setInterval(_this.next,_this.interval);
	}

	this.stop_timer = function()
	{
		clearInterval(_this.timer);
	}

	this.timer = setInterval(_this.next,_this.interval);

	el.mouseleave(function(){
		_this.start_timer();
	});

	el.mouseenter(function(){
		_this.stop_timer();
	})
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////
/* click_log */
//////////////////////////////////////////////////////////////////////////////////////////////////////////
var click_log = function (division) {
	
	$.ajax({
		type	: 'GET',
		url		: '/log/click_log',
		data	: { click_division:division },
		success	: function(data) {
			//console.log(data);
		}
	});
	
}


// (s) 전체구매 내역 리스트 처리 - theRok - 2016.11.07
$(document).on('click','#btn_buy_all_episode_list',function(){
	if (typeof($('#buy_all_episode_list')) != "undefined")
	{
		$('#buy_all_episode_list').toggle();
	}
});
// (e) 전체구매 내역 리스트 처리 - theRok - 2016.11.07

// 숫자 타입에서 쓸 수 있도록 format() 함수 추가 - theRok - 2016-12-13
Number.prototype.format = function(){
    if(this==0) return 0;
 
    var reg = /(^[+-]?\d+)(\d{3})/;
    var n = (this + '');
 
    while (reg.test(n)) n = n.replace(reg, '$1' + ',' + '$2');
 
    return n;
};
 
// 문자열 타입에서 쓸 수 있도록 format() 함수 추가 - theRok - 2016-12-13
String.prototype.format = function(){
    var num = parseFloat(this);
    if( isNaN(num) ) return "0";
 
    return num.format();
};

// rss to sjon - theRok - 2017-01-11
//jQuery extension to fetch an rss feed and return it as json via YQL
//created by dboz@airshp.com
(function($) {
  
	$.extend({
		feedToJson: function(options, callback) {
			if ($.isFunction(options)) {
			  callback = options;
			  options = null;
			}
			options = $.extend($.feedToJson.defaults,options);
			var url = options.yqlURL + options.yqlQS + "'" + encodeURIComponent(options.feed) + "'" + "&_nocache=" + options.cacheBuster;
			return $.getJSON(url, function(data){  
					//console.log(data.query.results);
					data = data.query.results;
					$.isFunction(callback) && callback(data); //allows the callback function to be the only option
					$.isFunction(options.success) && options.success(data);
				}); 
		}
	});
  
  //defaults
  $.feedToJson.defaults = {
	yqlURL : 'http://query.yahooapis.com/v1/public/yql',  //yql 
	yqlQS : '?format=json&callback=?&q=select%20*%20from%20rss%20where%20url%3D',  //yql query string
	feed:'http://instagr.am/tags/tacos/feed/recent.rss', //instagram recent posts tagged 'tacos'
	cachebuster: Math.floor((new Date().getTime()) / 1200 / 1000), //yql caches feeds, so we change the feed url every 20min
	success:null //success callback 
  }; 
  
})(jQuery);
// eo feedToJson

// 이벤트 결제상품 안내 레이어 - theRok - 2017-01-23
$(document).on('click','.btn_event_product_desc',function(){
	var $html = "<div style='width:300px;height:200px;background:#fff;'>본 이벤트는 2017년 1월 31일까지만 한시적으로 진행되는 이벤트입니다.<br/>이벤트 참여 회원은 매일 12시 APP에서 3코인씩 적립됩니다.<br/>(24:00 소멸되는 보너스코인입니다.)</div>",
		$id = "#alert_layer";

	$($id).html($html);
	ShowAlert($id);
});